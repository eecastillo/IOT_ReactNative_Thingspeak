module.exports = {
  fs: require('./fs'),
  dns: require('./dns'),
  zlib: require('./zlib'),
  crypto: require('./crypto'),
  readline: require('./readline'),
  child_process: require('./child_process')
}
