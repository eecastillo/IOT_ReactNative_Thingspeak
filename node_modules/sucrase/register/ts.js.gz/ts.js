require("../dist/register").registerTS();
