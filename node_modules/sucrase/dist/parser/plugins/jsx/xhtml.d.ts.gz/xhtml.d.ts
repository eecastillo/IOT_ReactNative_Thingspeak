declare const entities: {
    [name: string]: string;
};
export default entities;
