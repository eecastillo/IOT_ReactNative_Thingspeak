# normalize-css-color

Normalize a subset of CSS color values into integers
