export default function docsUrl(path) {
  return `https://reactnavigation.org/docs/4.x/${path}`;
}
