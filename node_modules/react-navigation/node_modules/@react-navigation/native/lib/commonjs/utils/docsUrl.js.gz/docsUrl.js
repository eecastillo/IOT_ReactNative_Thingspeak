"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = docsUrl;

function docsUrl(path) {
  return "https://reactnavigation.org/docs/".concat(path);
}
//# sourceMappingURL=docsUrl.js.map