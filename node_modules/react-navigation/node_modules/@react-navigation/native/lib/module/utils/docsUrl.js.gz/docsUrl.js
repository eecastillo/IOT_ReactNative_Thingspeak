export default function docsUrl(path) {
  return "https://reactnavigation.org/docs/".concat(path);
}
//# sourceMappingURL=docsUrl.js.map