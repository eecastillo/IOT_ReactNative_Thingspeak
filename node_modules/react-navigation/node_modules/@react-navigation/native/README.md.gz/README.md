# React Navigation Native

[![npm version](https://badge.fury.io/js/%40react-navigation%2Fnative.svg)](https://badge.fury.io/js/%40react-navigation%2Fnative) [![CircleCI badge](https://circleci.com/gh/react-navigation/native/tree/master.svg?style=shield)](https://circleci.com/gh/react-navigation/react-navigation-native/tree/master) [![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](https://reactnavigation.org/docs/contributing.html)

React Native support for React Navigation

## Docs

Documentation can be found on the [React Navigation website](https://reactnavigation.org/docs/getting-started.html).
