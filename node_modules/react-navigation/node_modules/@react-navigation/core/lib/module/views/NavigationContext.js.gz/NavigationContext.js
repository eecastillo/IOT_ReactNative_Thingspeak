import * as React from 'react'; // Change undefined to null in next major version bump

export default /*#__PURE__*/React.createContext(undefined);
//# sourceMappingURL=NavigationContext.js.map