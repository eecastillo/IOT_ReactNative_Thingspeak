import * as React from 'react'; // Only light and dark are supported currently. Arbitrary theming not available.

export default /*#__PURE__*/React.createContext('light');
//# sourceMappingURL=ThemeContext.js.map