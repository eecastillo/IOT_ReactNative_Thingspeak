export const JUMP_TO = 'Navigation/JUMP_TO';
export const jumpTo = payload => ({
  type: JUMP_TO,
  preserveFocus: true,
  ...payload
});
//# sourceMappingURL=SwitchActions.js.map