export default function docsUrl(path: string) {
  return `https://reactnavigation.org/docs/4.x/${path}`;
}
