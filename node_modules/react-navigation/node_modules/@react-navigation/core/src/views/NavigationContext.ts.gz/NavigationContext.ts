import * as React from 'react';

// Change undefined to null in next major version bump
export default React.createContext(undefined);
