"use strict";

var _index = require("./index");

var _virtualTypes = require("./path/generated/virtual-types");