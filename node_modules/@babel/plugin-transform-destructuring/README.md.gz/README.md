# @babel/plugin-transform-destructuring

> Compile ES2015 destructuring to ES5

See our website [@babel/plugin-transform-destructuring](https://babeljs.io/docs/en/babel-plugin-transform-destructuring) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-destructuring
```

or using yarn:

```sh
yarn add @babel/plugin-transform-destructuring --dev
```
