# @babel/plugin-transform-modules-umd

> This plugin transforms ES2015 modules to UMD

See our website [@babel/plugin-transform-modules-umd](https://babeljs.io/docs/en/babel-plugin-transform-modules-umd) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-modules-umd
```

or using yarn:

```sh
yarn add @babel/plugin-transform-modules-umd --dev
```
