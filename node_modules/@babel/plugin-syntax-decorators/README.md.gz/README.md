# @babel/plugin-syntax-decorators

> Allow parsing of decorators

See our website [@babel/plugin-syntax-decorators](https://babeljs.io/docs/en/babel-plugin-syntax-decorators) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-decorators
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-decorators --dev
```
