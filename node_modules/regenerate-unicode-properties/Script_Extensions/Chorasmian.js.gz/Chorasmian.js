const set = require('regenerate')();
set.addRange(0x10FB0, 0x10FCB);
module.exports = set;
