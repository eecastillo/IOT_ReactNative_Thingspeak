const set = require('regenerate')();
set.addRange(0x104B0, 0x104D3).addRange(0x104D8, 0x104FB);
module.exports = set;
