const set = require('regenerate')();
set.addRange(0x10860, 0x1087F);
module.exports = set;
