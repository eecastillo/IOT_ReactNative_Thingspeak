const set = require('regenerate')();
set.addRange(0x11C00, 0x11C08).addRange(0x11C0A, 0x11C36).addRange(0x11C38, 0x11C45).addRange(0x11C50, 0x11C6C);
module.exports = set;
