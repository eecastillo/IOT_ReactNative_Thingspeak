export declare const readFileAsync: (path: string) => Promise<any>;
