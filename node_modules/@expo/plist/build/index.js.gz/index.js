"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const build_1 = require("./build");
const parse_1 = require("./parse");
exports.default = { parse: parse_1.parse, build: build_1.build };
//# sourceMappingURL=index.js.map