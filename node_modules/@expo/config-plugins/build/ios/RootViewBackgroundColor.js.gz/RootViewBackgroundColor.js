"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setRootViewBackgroundColor = setRootViewBackgroundColor;
exports.getRootViewBackgroundColor = getRootViewBackgroundColor;
exports.withRootViewBackgroundColor = void 0;

function _iosPlugins() {
  const data = require("../plugins/ios-plugins");

  _iosPlugins = function () {
    return data;
  };

  return data;
}

function _normalizeColor() {
  const data = _interopRequireDefault(require("./utils/normalizeColor"));

  _normalizeColor = function () {
    return data;
  };

  return data;
}

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Maps to the template AppDelegate.m
const BACKGROUND_COLOR_KEY = 'RCTRootViewBackgroundColor';

const withRootViewBackgroundColor = config => {
  config = (0, _iosPlugins().withInfoPlist)(config, config => {
    config.modResults = setRootViewBackgroundColor(config, config.modResults);
    return config;
  });
  return config;
};

exports.withRootViewBackgroundColor = withRootViewBackgroundColor;

function setRootViewBackgroundColor(config, infoPlist) {
  const backgroundColor = getRootViewBackgroundColor(config);

  if (!backgroundColor) {
    delete infoPlist[BACKGROUND_COLOR_KEY];
  } else {
    let color = (0, _normalizeColor().default)(backgroundColor);

    if (!color) {
      throw new Error('Invalid background color on iOS');
    }

    color = (color << 24 | color >>> 8) >>> 0;
    infoPlist[BACKGROUND_COLOR_KEY] = color;
  }

  return infoPlist;
}

function getRootViewBackgroundColor(config) {
  var _config$ios;

  return ((_config$ios = config.ios) === null || _config$ios === void 0 ? void 0 : _config$ios.backgroundColor) || config.backgroundColor || null;
}
//# sourceMappingURL=RootViewBackgroundColor.js.map