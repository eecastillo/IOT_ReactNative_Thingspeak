"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getLocales = getLocales;
exports.setLocalesAsync = setLocalesAsync;
exports.getResolvedLocalesAsync = getResolvedLocalesAsync;
exports.withLocales = void 0;

function _jsonFile() {
  const data = _interopRequireDefault(require("@expo/json-file"));

  _jsonFile = function () {
    return data;
  };

  return data;
}

function fs() {
  const data = _interopRequireWildcard(require("fs-extra"));

  fs = function () {
    return data;
  };

  return data;
}

function _path() {
  const data = require("path");

  _path = function () {
    return data;
  };

  return data;
}

function _iosPlugins() {
  const data = require("../plugins/ios-plugins");

  _iosPlugins = function () {
    return data;
  };

  return data;
}

function _warnings() {
  const data = require("../utils/warnings");

  _warnings = function () {
    return data;
  };

  return data;
}

function _Xcodeproj() {
  const data = require("./utils/Xcodeproj");

  _Xcodeproj = function () {
    return data;
  };

  return data;
}

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const withLocales = config => {
  return (0, _iosPlugins().withXcodeProject)(config, async config => {
    config.modResults = await setLocalesAsync(config, {
      projectRoot: config.modRequest.projectRoot,
      project: config.modResults
    });
    return config;
  });
};

exports.withLocales = withLocales;

function getLocales(config) {
  var _config$locales;

  return (_config$locales = config.locales) !== null && _config$locales !== void 0 ? _config$locales : null;
}

async function setLocalesAsync(config, {
  projectRoot,
  project
}) {
  const locales = getLocales(config);

  if (!locales) {
    return project;
  } // possibly validate CFBundleAllowMixedLocalizations is enabled


  const localesMap = await getResolvedLocalesAsync(projectRoot, locales);
  const projectName = (0, _Xcodeproj().getProjectName)(projectRoot);
  const supportingDirectory = (0, _path().join)(projectRoot, 'ios', projectName, 'Supporting'); // TODO: Should we delete all before running? Revisit after we land on a lock file.

  const stringName = 'InfoPlist.strings';

  for (const [lang, localizationObj] of Object.entries(localesMap)) {
    const dir = (0, _path().join)(supportingDirectory, `${lang}.lproj`);
    await fs().ensureDir(dir);
    const strings = (0, _path().join)(dir, stringName);
    const buffer = [];

    for (const [plistKey, localVersion] of Object.entries(localizationObj)) {
      buffer.push(`${plistKey} = "${localVersion}";`);
    } // Write the file to the file system.


    await fs().writeFile(strings, buffer.join('\n')); // deep find the correct folder

    const group = (0, _Xcodeproj().ensureGroupRecursively)(project, `${projectName}/Supporting/${lang}.lproj`); // Ensure the file doesn't already exist

    if (!(group !== null && group !== void 0 && group.children.some(({
      comment
    }) => comment === stringName))) {
      // Only write the file if it doesn't already exist.
      project = (0, _Xcodeproj().addResourceFileToGroup)({
        filepath: strings,
        groupName: `${projectName}/Supporting/${lang}.lproj`,
        project,
        isBuildFile: true,
        verbose: true
      });
    }
  }

  return project;
}

async function getResolvedLocalesAsync(projectRoot, input) {
  const locales = {};

  for (const [lang, localeJsonPath] of Object.entries(input)) {
    if (typeof localeJsonPath === 'string') {
      try {
        locales[lang] = await _jsonFile().default.readAsync((0, _path().join)(projectRoot, localeJsonPath));
      } catch (e) {
        // Add a warning when a json file cannot be parsed.
        (0, _warnings().addWarningIOS)(`locales.${lang}`, `Failed to parse JSON of locale file for language: ${lang}`, 'https://docs.expo.dev/distribution/app-stores/#localizing-your-ios-app');
      }
    } else {
      // In the off chance that someone defined the locales json in the config, pass it directly to the object.
      // We do this to make the types more elegant.
      locales[lang] = localeJsonPath;
    }
  }

  return locales;
}
//# sourceMappingURL=Locales.js.map