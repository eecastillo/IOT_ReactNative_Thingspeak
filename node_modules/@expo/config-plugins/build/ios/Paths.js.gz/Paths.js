"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getAppDelegateFilePath = getAppDelegateFilePath;
exports.getFileInfo = getFileInfo;
exports.getAppDelegate = getAppDelegate;
exports.getSourceRoot = getSourceRoot;
exports.findSchemePaths = findSchemePaths;
exports.findSchemeNames = findSchemeNames;
exports.getAllXcodeProjectPaths = getAllXcodeProjectPaths;
exports.getXcodeProjectPath = getXcodeProjectPath;
exports.getAllPBXProjectPaths = getAllPBXProjectPaths;
exports.getPBXProjectPath = getPBXProjectPath;
exports.getAllInfoPlistPaths = getAllInfoPlistPaths;
exports.getInfoPlistPath = getInfoPlistPath;
exports.getAllEntitlementsPaths = getAllEntitlementsPaths;
exports.getEntitlementsPath = getEntitlementsPath;
exports.getSupportingPath = getSupportingPath;
exports.getExpoPlistPath = getExpoPlistPath;

function _fsExtra() {
  const data = require("fs-extra");

  _fsExtra = function () {
    return data;
  };

  return data;
}

function _glob() {
  const data = require("glob");

  _glob = function () {
    return data;
  };

  return data;
}

function path() {
  const data = _interopRequireWildcard(require("path"));

  path = function () {
    return data;
  };

  return data;
}

function _errors() {
  const data = require("../utils/errors");

  _errors = function () {
    return data;
  };

  return data;
}

function _warnings() {
  const data = require("../utils/warnings");

  _warnings = function () {
    return data;
  };

  return data;
}

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

const ignoredPaths = ['**/@(Carthage|Pods|vendor|node_modules)/**'];

function getAppDelegateFilePath(projectRoot) {
  const [using, ...extra] = (0, _glob().sync)('ios/*/AppDelegate.@(m|swift)', {
    absolute: true,
    cwd: projectRoot,
    ignore: ignoredPaths
  });

  if (!using) {
    throw new (_errors().UnexpectedError)(`Could not locate a valid AppDelegate at root: "${projectRoot}"`);
  }

  if (extra.length) {
    warnMultipleFiles({
      tag: 'app-delegate',
      fileName: 'AppDelegate',
      projectRoot,
      using,
      extra
    });
  }

  return using;
}

function getLanguage(filePath) {
  const extension = path().extname(filePath);

  switch (extension) {
    case '.m':
      return 'objc';

    case '.swift':
      return 'swift';

    default:
      throw new (_errors().UnexpectedError)(`Unexpected iOS file extension: ${extension}`);
  }
}

function getFileInfo(filePath) {
  return {
    path: path().normalize(filePath),
    contents: (0, _fsExtra().readFileSync)(filePath, 'utf8'),
    language: getLanguage(filePath)
  };
}

function getAppDelegate(projectRoot) {
  const filePath = getAppDelegateFilePath(projectRoot);
  return getFileInfo(filePath);
}

function getSourceRoot(projectRoot) {
  const appDelegate = getAppDelegate(projectRoot);
  return path().dirname(appDelegate.path);
}

function findSchemePaths(projectRoot) {
  return (0, _glob().sync)('ios/*.xcodeproj/xcshareddata/xcschemes/*.xcscheme', {
    absolute: true,
    cwd: projectRoot,
    ignore: ignoredPaths
  });
}

function findSchemeNames(projectRoot) {
  const schemePaths = findSchemePaths(projectRoot);
  return schemePaths.map(schemePath => path().basename(schemePath).split('.')[0]);
}

function getAllXcodeProjectPaths(projectRoot) {
  const iosFolder = 'ios';
  const pbxprojPaths = (0, _glob().sync)('**/*.xcodeproj', {
    cwd: projectRoot,
    ignore: ignoredPaths
  }).filter(project => !/test|example|sample/i.test(project) || path().dirname(project) === iosFolder).sort(project => path().dirname(project) === iosFolder ? -1 : 1) // sort alphabetically to ensure this works the same across different devices (Fail in CI (linux) without this)
  .sort();

  if (!pbxprojPaths.length) {
    throw new (_errors().UnexpectedError)(`Failed to locate the ios/*.xcodeproj files relative to path "${projectRoot}".`);
  }

  return pbxprojPaths.map(value => path().join(projectRoot, value));
}
/**
 * Get the pbxproj for the given path
 */


function getXcodeProjectPath(projectRoot) {
  const [using, ...extra] = getAllXcodeProjectPaths(projectRoot);

  if (extra.length) {
    warnMultipleFiles({
      tag: 'xcodeproj',
      fileName: '*.xcodeproj',
      projectRoot,
      using,
      extra
    });
  }

  return using;
}

function getAllPBXProjectPaths(projectRoot) {
  const projectPaths = getAllXcodeProjectPaths(projectRoot);
  const paths = projectPaths.map(value => path().join(value, 'project.pbxproj')).filter(value => (0, _fsExtra().pathExistsSync)(value));

  if (!paths.length) {
    throw new (_errors().UnexpectedError)(`Failed to locate the ios/*.xcodeproj/project.pbxproj files relative to path "${projectRoot}".`);
  }

  return paths;
}

function getPBXProjectPath(projectRoot) {
  const [using, ...extra] = getAllPBXProjectPaths(projectRoot);

  if (extra.length) {
    warnMultipleFiles({
      tag: 'project-pbxproj',
      fileName: 'project.pbxproj',
      projectRoot,
      using,
      extra
    });
  }

  return using;
}

function getAllInfoPlistPaths(projectRoot) {
  const paths = (0, _glob().sync)('ios/*/Info.plist', {
    absolute: true,
    cwd: projectRoot,
    ignore: ignoredPaths
  }).sort( // longer name means more suffixes, we want the shortest possible one to be first.
  (a, b) => a.length - b.length);

  if (!paths.length) {
    throw new (_errors().UnexpectedError)(`Failed to locate Info.plist files relative to path "${projectRoot}".`);
  }

  return paths;
}

function getInfoPlistPath(projectRoot) {
  const [using, ...extra] = getAllInfoPlistPaths(projectRoot);

  if (extra.length) {
    warnMultipleFiles({
      tag: 'info-plist',
      fileName: 'Info.plist',
      projectRoot,
      using,
      extra
    });
  }

  return using;
}

function getAllEntitlementsPaths(projectRoot) {
  const paths = (0, _glob().sync)('ios/*/*.entitlements', {
    absolute: true,
    cwd: projectRoot,
    ignore: ignoredPaths
  });
  return paths;
}
/**
 * Get the entitlements file path if it exists.
 *
 * @param projectRoot
 */


function getEntitlementsPath(projectRoot) {
  const [using, ...extra] = getAllEntitlementsPaths(projectRoot);

  if (extra.length) {
    warnMultipleFiles({
      tag: 'entitlements',
      fileName: '*.entitlements',
      projectRoot,
      using,
      extra
    });
  }

  return using !== null && using !== void 0 ? using : null;
}

function getSupportingPath(projectRoot) {
  return path().resolve(projectRoot, 'ios', path().basename(getSourceRoot(projectRoot)), 'Supporting');
}

function getExpoPlistPath(projectRoot) {
  const supportingPath = getSupportingPath(projectRoot);
  return path().join(supportingPath, 'Expo.plist');
}

function warnMultipleFiles({
  tag,
  fileName,
  projectRoot,
  using,
  extra
}) {
  const usingPath = projectRoot ? path().relative(projectRoot, using) : using;
  const extraPaths = projectRoot ? extra.map(v => path().relative(projectRoot, v)) : extra;
  (0, _warnings().addWarningIOS)(`paths-${tag}`, `Found multiple ${fileName} file paths, using "${usingPath}". Ignored paths: ${JSON.stringify(extraPaths)}`);
}
//# sourceMappingURL=Paths.js.map