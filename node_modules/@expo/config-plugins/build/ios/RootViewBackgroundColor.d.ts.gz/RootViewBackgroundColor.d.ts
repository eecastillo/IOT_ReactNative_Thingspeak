import { ExpoConfig } from '@expo/config-types';
import { ConfigPlugin } from '../Plugin.types';
import { InfoPlist } from './IosConfig.types';
export declare const withRootViewBackgroundColor: ConfigPlugin;
export declare function setRootViewBackgroundColor(config: Pick<ExpoConfig, 'backgroundColor' | 'ios'>, infoPlist: InfoPlist): InfoPlist;
export declare function getRootViewBackgroundColor(config: Pick<ExpoConfig, 'ios' | 'backgroundColor'>): string | null;
