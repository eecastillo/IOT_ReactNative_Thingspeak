"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getBranchApiKey = getBranchApiKey;
exports.setBranchApiKey = setBranchApiKey;
exports.withBranch = void 0;

function _iosPlugins() {
  const data = require("../plugins/ios-plugins");

  _iosPlugins = function () {
    return data;
  };

  return data;
}

const withBranch = (0, _iosPlugins().createInfoPlistPlugin)(setBranchApiKey, 'withBranch');
exports.withBranch = withBranch;

function getBranchApiKey(config) {
  var _config$ios$config$br, _config$ios, _config$ios$config, _config$ios$config$br2;

  return (_config$ios$config$br = (_config$ios = config.ios) === null || _config$ios === void 0 ? void 0 : (_config$ios$config = _config$ios.config) === null || _config$ios$config === void 0 ? void 0 : (_config$ios$config$br2 = _config$ios$config.branch) === null || _config$ios$config$br2 === void 0 ? void 0 : _config$ios$config$br2.apiKey) !== null && _config$ios$config$br !== void 0 ? _config$ios$config$br : null;
}

function setBranchApiKey(config, infoPlist) {
  const apiKey = getBranchApiKey(config);

  if (apiKey === null) {
    return infoPlist;
  }

  return { ...infoPlist,
    branch_key: {
      live: apiKey
    }
  };
}
//# sourceMappingURL=Branch.js.map