import { ConfigPlugin, ExportedConfig, ExportedConfigWithProps, ModPlatform } from '../Plugin.types';
import { BaseModOptions } from './withMod';
export declare type ForwardedBaseModOptions = Partial<Pick<BaseModOptions, 'saveToInternal' | 'skipEmptyMod'>>;
export declare type BaseModProviderMethods<ModType, Props extends ForwardedBaseModOptions = ForwardedBaseModOptions> = {
    getFilePath: (config: ExportedConfigWithProps<ModType>, props: Props) => Promise<string> | string;
    read: (filePath: string, config: ExportedConfigWithProps<ModType>, props: Props) => Promise<ModType> | ModType;
    write: (filePath: string, config: ExportedConfigWithProps<ModType>, props: Props) => Promise<void> | void;
};
export declare type CreateBaseModProps<ModType, Props extends ForwardedBaseModOptions = ForwardedBaseModOptions> = {
    methodName: string;
    platform: ModPlatform;
    modName: string;
} & BaseModProviderMethods<ModType, Props>;
export declare function createBaseMod<ModType, Props extends ForwardedBaseModOptions = ForwardedBaseModOptions>({ methodName, platform, modName, getFilePath, read, write, }: CreateBaseModProps<ModType, Props>): ConfigPlugin<Props | void>;
export declare function assertModResults(results: any, platformName: string, modName: string): any;
export declare function createPlatformBaseMod<ModType, Props extends ForwardedBaseModOptions = ForwardedBaseModOptions>({ modName, ...props }: Omit<CreateBaseModProps<ModType, Props>, 'methodName'>): ConfigPlugin<void | Props>;
export declare function provider<ModType, Props extends ForwardedBaseModOptions = ForwardedBaseModOptions>(props: BaseModProviderMethods<ModType, Props>): BaseModProviderMethods<ModType, Props>;
export declare function withGeneratedBaseMods<ModName extends string>(config: ExportedConfig, { platform, providers, ...props }: ForwardedBaseModOptions & {
    platform: ModPlatform;
    providers: Partial<Record<ModName, BaseModProviderMethods<any, any>>>;
}): ExportedConfig;
