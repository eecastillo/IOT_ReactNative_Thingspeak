"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.withIosBaseMods = withIosBaseMods;
exports.getIosModFileProviders = getIosModFileProviders;
exports.getIosIntrospectModFileProviders = getIosIntrospectModFileProviders;

function _plist() {
  const data = _interopRequireDefault(require("@expo/plist"));

  _plist = function () {
    return data;
  };

  return data;
}

function _assert() {
  const data = _interopRequireDefault(require("assert"));

  _assert = function () {
    return data;
  };

  return data;
}

function _fs() {
  const data = require("fs");

  _fs = function () {
    return data;
  };

  return data;
}

function _path() {
  const data = _interopRequireDefault(require("path"));

  _path = function () {
    return data;
  };

  return data;
}

function _xcode() {
  const data = _interopRequireDefault(require("xcode"));

  _xcode = function () {
    return data;
  };

  return data;
}

function _ios() {
  const data = require("../ios");

  _ios = function () {
    return data;
  };

  return data;
}

function _getInfoPlistPath() {
  const data = require("../ios/utils/getInfoPlistPath");

  _getInfoPlistPath = function () {
    return data;
  };

  return data;
}

function _modules() {
  const data = require("../utils/modules");

  _modules = function () {
    return data;
  };

  return data;
}

function _sortObject() {
  const data = require("../utils/sortObject");

  _sortObject = function () {
    return data;
  };

  return data;
}

function _warnings() {
  const data = require("../utils/warnings");

  _warnings = function () {
    return data;
  };

  return data;
}

function _createBaseMod() {
  const data = require("./createBaseMod");

  _createBaseMod = function () {
    return data;
  };

  return data;
}

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const {
  readFile,
  writeFile
} = _fs().promises;

const defaultProviders = {
  dangerous: (0, _createBaseMod().provider)({
    getFilePath() {
      return '';
    },

    async read() {
      return {};
    },

    async write() {}

  }),
  // Append a rule to supply AppDelegate data to mods on `mods.ios.appDelegate`
  appDelegate: (0, _createBaseMod().provider)({
    getFilePath({
      modRequest: {
        projectRoot
      }
    }) {
      return _ios().Paths.getAppDelegateFilePath(projectRoot);
    },

    async read(filePath) {
      return _ios().Paths.getFileInfo(filePath);
    },

    async write(filePath, {
      modResults: {
        contents
      }
    }) {
      await writeFile(filePath, contents);
    }

  }),
  // Append a rule to supply Expo.plist data to mods on `mods.ios.expoPlist`
  expoPlist: (0, _createBaseMod().provider)({
    getFilePath({
      modRequest: {
        platformProjectRoot,
        projectName
      }
    }) {
      const supportingDirectory = _path().default.join(platformProjectRoot, projectName, 'Supporting');

      return _path().default.resolve(supportingDirectory, 'Expo.plist');
    },

    async read(filePath) {
      return _plist().default.parse(await readFile(filePath, 'utf8'));
    },

    async write(filePath, {
      modResults
    }) {
      await writeFile(filePath, _plist().default.build((0, _sortObject().sortObject)(modResults)));
    }

  }),
  // Append a rule to supply .xcodeproj data to mods on `mods.ios.xcodeproj`
  xcodeproj: (0, _createBaseMod().provider)({
    getFilePath({
      modRequest: {
        projectRoot
      }
    }) {
      return _ios().Paths.getPBXProjectPath(projectRoot);
    },

    async read(filePath) {
      const project = _xcode().default.project(filePath);

      project.parseSync();
      return project;
    },

    async write(filePath, {
      modResults
    }) {
      await writeFile(filePath, modResults.writeSync());
    }

  }),
  // Append a rule to supply Info.plist data to mods on `mods.ios.infoPlist`
  infoPlist: (0, _createBaseMod().provider)({
    getFilePath(config) {
      const infoPlistBuildProperty = (0, _getInfoPlistPath().getInfoPlistPathFromPbxproj)(config.modRequest.projectRoot);

      if (infoPlistBuildProperty) {
        //: [root]/myapp/ios/MyApp/Info.plist
        const infoPlistPath = _path().default.join( //: myapp/ios
        config.modRequest.platformProjectRoot, //: MyApp/Info.plist
        infoPlistBuildProperty);

        if ((0, _modules().fileExists)(infoPlistPath)) {
          return infoPlistPath;
        }

        (0, _warnings().addWarningIOS)('mods.ios.infoPlist', `Info.plist file linked to Xcode project does not exist: ${infoPlistPath}`);
      } else {
        (0, _warnings().addWarningIOS)('mods.ios.infoPlist', 'Failed to find Info.plist linked to Xcode project.');
      } // Fallback on glob...


      return _ios().Paths.getInfoPlistPath(config.modRequest.projectRoot);
    },

    async read(filePath, config) {
      // Apply all of the Info.plist values to the expo.ios.infoPlist object
      // TODO: Remove this in favor of just overwriting the Info.plist with the Expo object. This will enable people to actually remove values.
      if (!config.ios) config.ios = {};
      if (!config.ios.infoPlist) config.ios.infoPlist = {};
      const contents = await readFile(filePath, 'utf8');
      (0, _assert().default)(contents, 'Info.plist is empty');

      const modResults = _plist().default.parse(contents);

      config.ios.infoPlist = { ...(modResults || {}),
        ...config.ios.infoPlist
      };
      return config.ios.infoPlist;
    },

    async write(filePath, config) {
      // Update the contents of the static infoPlist object
      if (!config.ios) config.ios = {};
      config.ios.infoPlist = config.modResults;
      await writeFile(filePath, _plist().default.build((0, _sortObject().sortObject)(config.modResults)));
    }

  }),
  // Append a rule to supply .entitlements data to mods on `mods.ios.entitlements`
  entitlements: (0, _createBaseMod().provider)({
    getFilePath(config) {
      return _ios().Entitlements.getEntitlementsPath(config.modRequest.projectRoot);
    },

    async read(filePath, config) {
      const contents = await readFile(filePath, 'utf8');
      (0, _assert().default)(contents, 'Entitlements plist is empty');

      const modResults = _plist().default.parse(contents); // Apply all of the .entitlements values to the expo.ios.entitlements object
      // TODO: Remove this in favor of just overwriting the .entitlements with the Expo object. This will enable people to actually remove values.


      if (!config.ios) config.ios = {};
      if (!config.ios.entitlements) config.ios.entitlements = {};
      config.ios.entitlements = { ...(modResults || {}),
        ...config.ios.entitlements
      };
      return config.ios.entitlements;
    },

    async write(filePath, config) {
      // Update the contents of the static entitlements object
      if (!config.ios) {
        config.ios = {};
      }

      config.ios.entitlements = config.modResults;
      await writeFile(filePath, _plist().default.build((0, _sortObject().sortObject)(config.modResults)));
    }

  })
};

function withIosBaseMods(config, {
  providers,
  ...props
} = {}) {
  return (0, _createBaseMod().withGeneratedBaseMods)(config, { ...props,
    platform: 'ios',
    providers: providers !== null && providers !== void 0 ? providers : getIosModFileProviders()
  });
}

function getIosModFileProviders() {
  return defaultProviders;
}
/**
 * Get file providers that run introspection without modifying the actual native source code.
 * This can be used to determine the absolute static `ios.infoPlist` and `ios.entitlements` objects.
 *
 * @returns
 */


function getIosIntrospectModFileProviders() {
  const createIntrospectionProvider = (modName, {
    fallbackContents
  }) => {
    const realProvider = defaultProviders[modName];
    return (0, _createBaseMod().provider)({
      async getFilePath(...props) {
        try {
          return await realProvider.getFilePath(...props);
        } catch {
          // fallback to an empty string in introspection mode.
          return '';
        }
      },

      async read(...props) {
        try {
          return await realProvider.read(...props);
        } catch {
          // fallback if a file is missing in introspection mode.
          return fallbackContents;
        }
      },

      async write() {// write nothing in introspection mode.
      }

    });
  }; // dangerous should never be added


  return {
    // appDelegate: createIntrospectionProvider('appDelegate', {
    //   fallbackContents: {
    //     path: '',
    //     contents: '',
    //     language: 'objc',
    //   } as Paths.AppDelegateProjectFile,
    // }),
    // xcodeproj: createIntrospectionProvider('xcodeproj', {
    //   fallbackContents: {} as XcodeProject,
    // }),
    expoPlist: createIntrospectionProvider('expoPlist', {
      fallbackContents: {}
    }),
    infoPlist: {
      async getFilePath(...props) {
        try {
          return await defaultProviders.infoPlist.getFilePath(...props);
        } catch {
          return '';
        }
      },

      async read(filePath, config, props) {
        try {
          return await defaultProviders.infoPlist.read(filePath, config, props);
        } catch {
          var _config$ios$infoPlist, _config$ios;

          // Fallback to using the infoPlist object from the Expo config.
          return (_config$ios$infoPlist = (_config$ios = config.ios) === null || _config$ios === void 0 ? void 0 : _config$ios.infoPlist) !== null && _config$ios$infoPlist !== void 0 ? _config$ios$infoPlist : {
            CFBundleDevelopmentRegion: '$(DEVELOPMENT_LANGUAGE)',
            CFBundleExecutable: '$(EXECUTABLE_NAME)',
            CFBundleIdentifier: '$(PRODUCT_BUNDLE_IDENTIFIER)',
            CFBundleName: '$(PRODUCT_NAME)',
            CFBundlePackageType: '$(PRODUCT_BUNDLE_PACKAGE_TYPE)',
            CFBundleInfoDictionaryVersion: '6.0',
            CFBundleSignature: '????',
            LSRequiresIPhoneOS: true,
            NSAppTransportSecurity: {
              NSAllowsArbitraryLoads: true,
              NSExceptionDomains: {
                localhost: {
                  NSExceptionAllowsInsecureHTTPLoads: true
                }
              }
            },
            UILaunchStoryboardName: 'SplashScreen',
            UIRequiredDeviceCapabilities: ['armv7'],
            UIViewControllerBasedStatusBarAppearance: false,
            UIStatusBarStyle: 'UIStatusBarStyleDefault'
          };
        }
      },

      write(filePath, config) {
        // Update the contents of the static infoPlist object
        if (!config.ios) config.ios = {};
        config.ios.infoPlist = config.modResults;
      }

    },
    entitlements: {
      async getFilePath(...props) {
        try {
          return await defaultProviders.entitlements.getFilePath(...props);
        } catch {
          return '';
        }
      },

      async read(filePath, config, props) {
        try {
          return await defaultProviders.entitlements.read(filePath, config, props);
        } catch {
          var _config$ios$entitleme, _config$ios2;

          // Fallback to using the entitlements object from the Expo config.
          return (_config$ios$entitleme = (_config$ios2 = config.ios) === null || _config$ios2 === void 0 ? void 0 : _config$ios2.entitlements) !== null && _config$ios$entitleme !== void 0 ? _config$ios$entitleme : {};
        }
      },

      write(filePath, config) {
        // Update the contents of the static entitlements object
        if (!config.ios) config.ios = {};
        config.ios.entitlements = config.modResults;
      }

    }
  };
}
//# sourceMappingURL=withIosBaseMods.js.map