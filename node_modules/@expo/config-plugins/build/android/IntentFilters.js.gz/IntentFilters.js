"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getIntentFilters = getIntentFilters;
exports.setAndroidIntentFilters = setAndroidIntentFilters;
exports.default = renderIntentFilters;
exports.withAndroidIntentFilters = void 0;

function _xml2js() {
  const data = require("xml2js");

  _xml2js = function () {
    return data;
  };

  return data;
}

function _androidPlugins() {
  const data = require("../plugins/android-plugins");

  _androidPlugins = function () {
    return data;
  };

  return data;
}

function _Manifest() {
  const data = require("./Manifest");

  _Manifest = function () {
    return data;
  };

  return data;
}

// TODO: make it so intent filters aren't written again if you run the command again
const withAndroidIntentFilters = (0, _androidPlugins().createAndroidManifestPlugin)(setAndroidIntentFilters, 'withAndroidIntentFilters');
exports.withAndroidIntentFilters = withAndroidIntentFilters;

function getIntentFilters(config) {
  var _config$android$inten, _config$android;

  return (_config$android$inten = (_config$android = config.android) === null || _config$android === void 0 ? void 0 : _config$android.intentFilters) !== null && _config$android$inten !== void 0 ? _config$android$inten : [];
}

async function setAndroidIntentFilters(config, androidManifest) {
  var _mainActivity$intent;

  const intentFilters = getIntentFilters(config);

  if (!intentFilters.length) {
    return androidManifest;
  }

  const intentFiltersXML = renderIntentFilters(intentFilters).join('');
  const parser = new (_xml2js().Parser)();
  const intentFiltersJSON = await parser.parseStringPromise(intentFiltersXML);
  const mainActivity = (0, _Manifest().getMainActivityOrThrow)(androidManifest);
  mainActivity['intent-filter'] = (_mainActivity$intent = mainActivity['intent-filter']) === null || _mainActivity$intent === void 0 ? void 0 : _mainActivity$intent.concat(intentFiltersJSON['intent-filter']);
  return androidManifest;
}

function renderIntentFilters(intentFilters) {
  // returns an array of <intent-filter> tags:
  // [
  //   `<intent-filter>
  //     <data android:scheme="exp"/>
  //     <data android:scheme="exps"/>
  //
  //     <action android:name="android.intent.action.VIEW"/>
  //
  //     <category android:name="android.intent.category.DEFAULT"/>
  //     <category android:name="android.intent.category.BROWSABLE"/>
  //   </intent-filter>`,
  //   ...
  // ]
  return intentFilters.map(intentFilter => {
    const autoVerify = intentFilter.autoVerify ? ' android:autoVerify="true"' : '';
    return `<intent-filter${autoVerify}>
      ${renderIntentFilterData(intentFilter.data)}
      <action android:name="android.intent.action.${intentFilter.action}"/>
      ${renderIntentFilterCategory(intentFilter.category)}
    </intent-filter>`;
  });
}

function renderIntentFilterDatumEntries(datum = {}) {
  const entries = [];

  for (const [key, value] of Object.entries(datum)) {
    entries.push(`android:${key}="${value}"`);
  }

  return entries.join(' ');
}

function renderIntentFilterData(data) {
  return (Array.isArray(data) ? data : [data]).filter(Boolean).map(datum => `<data ${renderIntentFilterDatumEntries(datum)}/>`).join('\n');
}

function renderIntentFilterCategory(category) {
  return (Array.isArray(category) ? category : [category]).filter(Boolean).map(cat => `<category android:name="android.intent.category.${cat}"/>`).join('\n');
}
//# sourceMappingURL=IntentFilters.js.map