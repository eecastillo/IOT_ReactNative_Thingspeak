"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setNavigationBarColors = setNavigationBarColors;
exports.setNavigationBarStyles = setNavigationBarStyles;
exports.getNavigationBarImmersiveMode = getNavigationBarImmersiveMode;
exports.getNavigationBarColor = getNavigationBarColor;
exports.getNavigationBarStyle = getNavigationBarStyle;
exports.withNavigationBar = void 0;

function _androidPlugins() {
  const data = require("../plugins/android-plugins");

  _androidPlugins = function () {
    return data;
  };

  return data;
}

function _warnings() {
  const data = require("../utils/warnings");

  _warnings = function () {
    return data;
  };

  return data;
}

function _Colors() {
  const data = require("./Colors");

  _Colors = function () {
    return data;
  };

  return data;
}

function _Resources() {
  const data = require("./Resources");

  _Resources = function () {
    return data;
  };

  return data;
}

function _Styles() {
  const data = require("./Styles");

  _Styles = function () {
    return data;
  };

  return data;
}

const NAVIGATION_BAR_COLOR = 'navigationBarColor';

const withNavigationBar = config => {
  const immersiveMode = getNavigationBarImmersiveMode(config);

  if (immersiveMode) {
    // Immersive mode needs to be set programmatically
    // TODO: Resolve
    (0, _warnings().addWarningAndroid)('androidNavigationBar.visible', 'Hiding the navigation bar must be done programmatically', 'https://developer.android.com/training/system-ui/immersive');
  }

  config = withNavigationBarColors(config);
  config = withNavigationBarStyles(config);
  return config;
};

exports.withNavigationBar = withNavigationBar;

const withNavigationBarColors = config => {
  return (0, _androidPlugins().withAndroidColors)(config, config => {
    config.modResults = setNavigationBarColors(config, config.modResults);
    return config;
  });
};

const withNavigationBarStyles = config => {
  return (0, _androidPlugins().withAndroidStyles)(config, config => {
    config.modResults = setNavigationBarStyles(config, config.modResults);
    return config;
  });
};

function setNavigationBarColors(config, colors) {
  const hexString = getNavigationBarColor(config);

  if (hexString) {
    colors = (0, _Colors().setColorItem)((0, _Resources().buildResourceItem)({
      name: NAVIGATION_BAR_COLOR,
      value: hexString
    }), colors);
  }

  return colors;
}

function setNavigationBarStyles(config, styles) {
  styles = (0, _Styles().assignStylesValue)(styles, {
    add: !!getNavigationBarColor(config),
    parent: (0, _Styles().getAppThemeLightNoActionBarGroup)(),
    name: `android:${NAVIGATION_BAR_COLOR}`,
    value: `@color/${NAVIGATION_BAR_COLOR}`
  });
  styles = (0, _Styles().assignStylesValue)(styles, {
    add: getNavigationBarStyle(config) === 'dark-content',
    parent: (0, _Styles().getAppThemeLightNoActionBarGroup)(),
    name: 'android:windowLightNavigationBar',
    value: 'true'
  });
  return styles;
}

function getNavigationBarImmersiveMode(config) {
  var _config$androidNaviga;

  return ((_config$androidNaviga = config.androidNavigationBar) === null || _config$androidNaviga === void 0 ? void 0 : _config$androidNaviga.visible) || null;
}

function getNavigationBarColor(config) {
  var _config$androidNaviga2;

  return ((_config$androidNaviga2 = config.androidNavigationBar) === null || _config$androidNaviga2 === void 0 ? void 0 : _config$androidNaviga2.backgroundColor) || null;
}

function getNavigationBarStyle(config) {
  var _config$androidNaviga3;

  return ((_config$androidNaviga3 = config.androidNavigationBar) === null || _config$androidNaviga3 === void 0 ? void 0 : _config$androidNaviga3.barStyle) || 'light-content';
}
//# sourceMappingURL=NavigationBar.js.map