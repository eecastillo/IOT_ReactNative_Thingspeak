"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getRootViewBackgroundColor = getRootViewBackgroundColor;
exports.withRootViewBackgroundColorStyles = exports.withRootViewBackgroundColorColors = exports.withRootViewBackgroundColor = void 0;

function _androidPlugins() {
  const data = require("../plugins/android-plugins");

  _androidPlugins = function () {
    return data;
  };

  return data;
}

function _Colors() {
  const data = require("./Colors");

  _Colors = function () {
    return data;
  };

  return data;
}

function _Styles() {
  const data = require("./Styles");

  _Styles = function () {
    return data;
  };

  return data;
}

const ANDROID_WINDOW_BACKGROUND = 'android:windowBackground';
const WINDOW_BACKGROUND_COLOR = 'activityBackground';

const withRootViewBackgroundColor = config => {
  config = withRootViewBackgroundColorColors(config);
  config = withRootViewBackgroundColorStyles(config);
  return config;
};

exports.withRootViewBackgroundColor = withRootViewBackgroundColor;

const withRootViewBackgroundColorColors = config => {
  return (0, _androidPlugins().withAndroidColors)(config, async config => {
    config.modResults = (0, _Colors().assignColorValue)(config.modResults, {
      value: getRootViewBackgroundColor(config),
      name: WINDOW_BACKGROUND_COLOR
    });
    return config;
  });
};

exports.withRootViewBackgroundColorColors = withRootViewBackgroundColorColors;

const withRootViewBackgroundColorStyles = config => {
  return (0, _androidPlugins().withAndroidStyles)(config, async config => {
    config.modResults = (0, _Styles().assignStylesValue)(config.modResults, {
      add: !!getRootViewBackgroundColor(config),
      parent: (0, _Styles().getAppThemeLightNoActionBarGroup)(),
      name: ANDROID_WINDOW_BACKGROUND,
      value: `@color/${WINDOW_BACKGROUND_COLOR}`
    });
    return config;
  });
};

exports.withRootViewBackgroundColorStyles = withRootViewBackgroundColorStyles;

function getRootViewBackgroundColor(config) {
  var _config$android;

  return ((_config$android = config.android) === null || _config$android === void 0 ? void 0 : _config$android.backgroundColor) || config.backgroundColor || null;
}
//# sourceMappingURL=RootViewBackgroundColor.js.map