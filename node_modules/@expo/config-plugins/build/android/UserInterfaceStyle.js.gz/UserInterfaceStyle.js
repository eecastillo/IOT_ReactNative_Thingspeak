"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getUserInterfaceStyle = getUserInterfaceStyle;
exports.setUiModeAndroidManifest = setUiModeAndroidManifest;
exports.addOnConfigurationChangedMainActivity = addOnConfigurationChangedMainActivity;
exports.addJavaImports = addJavaImports;
exports.withUiModeMainActivity = exports.withUiModeManifest = exports.ON_CONFIGURATION_CHANGED = exports.CONFIG_CHANGES_ATTRIBUTE = void 0;

function _androidPlugins() {
  const data = require("../plugins/android-plugins");

  _androidPlugins = function () {
    return data;
  };

  return data;
}

function _warnings() {
  const data = require("../utils/warnings");

  _warnings = function () {
    return data;
  };

  return data;
}

function _Manifest() {
  const data = require("./Manifest");

  _Manifest = function () {
    return data;
  };

  return data;
}

const CONFIG_CHANGES_ATTRIBUTE = 'android:configChanges';
exports.CONFIG_CHANGES_ATTRIBUTE = CONFIG_CHANGES_ATTRIBUTE;
const ON_CONFIGURATION_CHANGED = `
public class MainActivity extends ReactActivity {

    // Added automatically by Expo Config
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Intent intent = new Intent("onConfigurationChanged");
        intent.putExtra("newConfig", newConfig);
        sendBroadcast(intent);
    }
`;
exports.ON_CONFIGURATION_CHANGED = ON_CONFIGURATION_CHANGED;
const withUiModeManifest = (0, _androidPlugins().createAndroidManifestPlugin)(setUiModeAndroidManifest, 'withUiModeManifest');
exports.withUiModeManifest = withUiModeManifest;

const withUiModeMainActivity = config => {
  return (0, _androidPlugins().withMainActivity)(config, config => {
    if (config.modResults.language === 'java') {
      config.modResults.contents = addOnConfigurationChangedMainActivity(config, config.modResults.contents);
    } else {
      (0, _warnings().addWarningAndroid)('android.userInterfaceStyle', `Cannot automatically configure MainActivity if it's not java`);
    }

    return config;
  });
};

exports.withUiModeMainActivity = withUiModeMainActivity;

function getUserInterfaceStyle(config) {
  var _ref, _config$android$userI, _config$android;

  return (_ref = (_config$android$userI = (_config$android = config.android) === null || _config$android === void 0 ? void 0 : _config$android.userInterfaceStyle) !== null && _config$android$userI !== void 0 ? _config$android$userI : config.userInterfaceStyle) !== null && _ref !== void 0 ? _ref : 'light';
}

function setUiModeAndroidManifest(config, androidManifest) {
  const userInterfaceStyle = getUserInterfaceStyle(config); // TODO: Remove this if we decide to remove any uiMode configuration when not specified

  if (!userInterfaceStyle) {
    return androidManifest;
  }

  const mainActivity = (0, _Manifest().getMainActivityOrThrow)(androidManifest);
  mainActivity.$[CONFIG_CHANGES_ATTRIBUTE] = 'keyboard|keyboardHidden|orientation|screenSize|uiMode';
  return androidManifest;
}

function addOnConfigurationChangedMainActivity(config, mainActivity) {
  var _mainActivity$match;

  const userInterfaceStyle = getUserInterfaceStyle(config);

  if (!userInterfaceStyle) {
    return mainActivity;
  } // Cruzan: this is not ideal, but I'm not sure of a better way to handle writing to MainActivity.java


  if ((_mainActivity$match = mainActivity.match(`onConfigurationChanged`)) !== null && _mainActivity$match !== void 0 && _mainActivity$match.length) {
    return mainActivity;
  }

  const MainActivityWithImports = addJavaImports(mainActivity, ['android.content.Intent', 'android.content.res.Configuration'], true);
  const pattern = new RegExp(`public class MainActivity extends ReactActivity {`);
  return MainActivityWithImports.replace(pattern, ON_CONFIGURATION_CHANGED);
} // TODO: we should have a generic utility for doing this


function addJavaImports(javaSource, javaImports, isJava) {
  const lines = javaSource.split('\n');
  const lineIndexWithPackageDeclaration = lines.findIndex(line => line.match(/^package .*;?$/));

  for (const javaImport of javaImports) {
    if (!javaSource.includes(javaImport)) {
      const importStatement = `import ${javaImport}${isJava ? ';' : ''}`;
      lines.splice(lineIndexWithPackageDeclaration + 1, 0, importStatement);
    }
  }

  return lines.join('\n');
}
//# sourceMappingURL=UserInterfaceStyle.js.map