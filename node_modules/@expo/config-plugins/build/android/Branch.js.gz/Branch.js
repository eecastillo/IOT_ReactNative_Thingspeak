"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getBranchApiKey = getBranchApiKey;
exports.setBranchApiKey = setBranchApiKey;
exports.withBranch = void 0;

function _androidPlugins() {
  const data = require("../plugins/android-plugins");

  _androidPlugins = function () {
    return data;
  };

  return data;
}

function _Manifest() {
  const data = require("./Manifest");

  _Manifest = function () {
    return data;
  };

  return data;
}

const META_BRANCH_KEY = 'io.branch.sdk.BranchKey';
const withBranch = (0, _androidPlugins().createAndroidManifestPlugin)(setBranchApiKey, 'withBranch');
exports.withBranch = withBranch;

function getBranchApiKey(config) {
  var _config$android$confi, _config$android, _config$android$confi2, _config$android$confi3;

  return (_config$android$confi = (_config$android = config.android) === null || _config$android === void 0 ? void 0 : (_config$android$confi2 = _config$android.config) === null || _config$android$confi2 === void 0 ? void 0 : (_config$android$confi3 = _config$android$confi2.branch) === null || _config$android$confi3 === void 0 ? void 0 : _config$android$confi3.apiKey) !== null && _config$android$confi !== void 0 ? _config$android$confi : null;
}

function setBranchApiKey(config, androidManifest) {
  const apiKey = getBranchApiKey(config);
  const mainApplication = (0, _Manifest().getMainApplicationOrThrow)(androidManifest);

  if (apiKey) {
    // If the item exists, add it back
    (0, _Manifest().addMetaDataItemToMainApplication)(mainApplication, META_BRANCH_KEY, apiKey);
  } else {
    // Remove any existing item
    (0, _Manifest().removeMetaDataItemFromMainApplication)(mainApplication, META_BRANCH_KEY);
  }

  return androidManifest;
}
//# sourceMappingURL=Branch.js.map