import { ExpoConfig } from '@expo/config-types';
import { ConfigPlugin } from '../Plugin.types';
import { ResourceXML } from './Resources';
export declare const withNavigationBar: ConfigPlugin;
export declare function setNavigationBarColors(config: Pick<ExpoConfig, 'androidNavigationBar'>, colors: ResourceXML): ResourceXML;
export declare function setNavigationBarStyles(config: Pick<ExpoConfig, 'androidNavigationBar'>, styles: ResourceXML): ResourceXML;
export declare function getNavigationBarImmersiveMode(config: Pick<ExpoConfig, 'androidNavigationBar'>): "leanback" | "immersive" | "sticky-immersive" | null;
export declare function getNavigationBarColor(config: Pick<ExpoConfig, 'androidNavigationBar'>): string | null;
export declare function getNavigationBarStyle(config: Pick<ExpoConfig, 'androidNavigationBar'>): "light-content" | "dark-content";
