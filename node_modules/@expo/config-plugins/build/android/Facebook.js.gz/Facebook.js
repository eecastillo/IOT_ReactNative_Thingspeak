"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getFacebookScheme = getFacebookScheme;
exports.getFacebookAppId = getFacebookAppId;
exports.getFacebookDisplayName = getFacebookDisplayName;
exports.getFacebookAutoInitEnabled = getFacebookAutoInitEnabled;
exports.getFacebookAutoLogAppEvents = getFacebookAutoLogAppEvents;
exports.getFacebookAdvertiserIDCollection = getFacebookAdvertiserIDCollection;
exports.setFacebookConfig = setFacebookConfig;
exports.withFacebookManifest = exports.withFacebookAppIdString = void 0;

function _androidPlugins() {
  const data = require("../plugins/android-plugins");

  _androidPlugins = function () {
    return data;
  };

  return data;
}

function _Manifest() {
  const data = require("./Manifest");

  _Manifest = function () {
    return data;
  };

  return data;
}

function _Resources() {
  const data = require("./Resources");

  _Resources = function () {
    return data;
  };

  return data;
}

function _Strings() {
  const data = require("./Strings");

  _Strings = function () {
    return data;
  };

  return data;
}

const CUSTOM_TAB_ACTIVITY = 'com.facebook.CustomTabActivity';
const STRING_FACEBOOK_APP_ID = 'facebook_app_id';
const META_APP_ID = 'com.facebook.sdk.ApplicationId';
const META_APP_NAME = 'com.facebook.sdk.ApplicationName';
const META_AUTO_INIT = 'com.facebook.sdk.AutoInitEnabled';
const META_AUTO_LOG_APP_EVENTS = 'com.facebook.sdk.AutoLogAppEventsEnabled';
const META_AD_ID_COLLECTION = 'com.facebook.sdk.AdvertiserIDCollectionEnabled';
const withFacebookAppIdString = (0, _androidPlugins().createStringsXmlPlugin)(applyFacebookAppIdString, 'withFacebookAppIdString');
exports.withFacebookAppIdString = withFacebookAppIdString;
const withFacebookManifest = (0, _androidPlugins().createAndroidManifestPlugin)(setFacebookConfig, 'withFacebookManifest');
exports.withFacebookManifest = withFacebookManifest;

function buildXMLItem({
  head,
  children
}) {
  return { ...(children !== null && children !== void 0 ? children : {}),
    $: head
  };
}

function buildAndroidItem(datum) {
  const item = typeof datum === 'string' ? {
    name: datum
  } : datum;
  const head = (0, _Manifest().prefixAndroidKeys)(item);
  return buildXMLItem({
    head
  });
}

function getFacebookSchemeActivity(scheme) {
  /**
  <activity
    android:name="com.facebook.CustomTabActivity"
    android:exported="true">
    <intent-filter>
        <action android:name="android.intent.action.VIEW" />
        <category android:name="android.intent.category.DEFAULT" />
        <category android:name="android.intent.category.BROWSABLE" />
        <data android:scheme="${scheme}" />
    </intent-filter>
  </activity>
   */
  return buildXMLItem({
    head: (0, _Manifest().prefixAndroidKeys)({
      name: CUSTOM_TAB_ACTIVITY,
      exported: 'true'
    }),
    children: {
      'intent-filter': [{
        action: [buildAndroidItem('android.intent.action.VIEW')],
        category: [buildAndroidItem('android.intent.category.DEFAULT'), buildAndroidItem('android.intent.category.BROWSABLE')],
        data: [buildAndroidItem({
          scheme
        })]
      }]
    }
  });
}

function getFacebookScheme(config) {
  var _config$facebookSchem;

  return (_config$facebookSchem = config.facebookScheme) !== null && _config$facebookSchem !== void 0 ? _config$facebookSchem : null;
}

function getFacebookAppId(config) {
  var _config$facebookAppId;

  return (_config$facebookAppId = config.facebookAppId) !== null && _config$facebookAppId !== void 0 ? _config$facebookAppId : null;
}

function getFacebookDisplayName(config) {
  var _config$facebookDispl;

  return (_config$facebookDispl = config.facebookDisplayName) !== null && _config$facebookDispl !== void 0 ? _config$facebookDispl : null;
}

function getFacebookAutoInitEnabled(config) {
  var _config$facebookAutoI;

  return (_config$facebookAutoI = config.facebookAutoInitEnabled) !== null && _config$facebookAutoI !== void 0 ? _config$facebookAutoI : null;
}

function getFacebookAutoLogAppEvents(config) {
  var _config$facebookAutoL;

  return (_config$facebookAutoL = config.facebookAutoLogAppEventsEnabled) !== null && _config$facebookAutoL !== void 0 ? _config$facebookAutoL : null;
}

function getFacebookAdvertiserIDCollection(config) {
  var _config$facebookAdver;

  return (_config$facebookAdver = config.facebookAdvertiserIDCollectionEnabled) !== null && _config$facebookAdver !== void 0 ? _config$facebookAdver : null;
}

function ensureFacebookActivity({
  mainApplication,
  scheme
}) {
  if (Array.isArray(mainApplication.activity)) {
    // Remove all Facebook CustomTabActivities first
    mainApplication.activity = mainApplication.activity.filter(activity => {
      var _activity$$;

      return ((_activity$$ = activity.$) === null || _activity$$ === void 0 ? void 0 : _activity$$['android:name']) !== CUSTOM_TAB_ACTIVITY;
    });
  } else {
    mainApplication.activity = [];
  } // If a new scheme is defined, append it to the activity.


  if (scheme) {
    mainApplication.activity.push(getFacebookSchemeActivity(scheme));
  }

  return mainApplication;
}

function applyFacebookAppIdString(config, stringsJSON) {
  const appId = getFacebookAppId(config);

  if (appId) {
    return (0, _Strings().setStringItem)([(0, _Resources().buildResourceItem)({
      name: STRING_FACEBOOK_APP_ID,
      value: appId
    })], stringsJSON);
  }

  return (0, _Strings().removeStringItem)(STRING_FACEBOOK_APP_ID, stringsJSON);
}

function setFacebookConfig(config, androidManifest) {
  const scheme = getFacebookScheme(config);
  const appId = getFacebookAppId(config);
  const displayName = getFacebookDisplayName(config);
  const autoInitEnabled = getFacebookAutoInitEnabled(config);
  const autoLogAppEvents = getFacebookAutoLogAppEvents(config);
  const advertiserIdCollection = getFacebookAdvertiserIDCollection(config);
  let mainApplication = (0, _Manifest().getMainApplicationOrThrow)(androidManifest);
  mainApplication = ensureFacebookActivity({
    scheme,
    mainApplication
  });

  if (appId) {
    mainApplication = (0, _Manifest().addMetaDataItemToMainApplication)(mainApplication, META_APP_ID, // The corresponding string is set in applyFacebookAppIdString
    `@string/${STRING_FACEBOOK_APP_ID}`);
  } else {
    mainApplication = (0, _Manifest().removeMetaDataItemFromMainApplication)(mainApplication, META_APP_ID);
  }

  if (displayName) {
    mainApplication = (0, _Manifest().addMetaDataItemToMainApplication)(mainApplication, META_APP_NAME, displayName);
  } else {
    mainApplication = (0, _Manifest().removeMetaDataItemFromMainApplication)(mainApplication, META_APP_NAME);
  }

  if (autoInitEnabled !== null) {
    mainApplication = (0, _Manifest().addMetaDataItemToMainApplication)(mainApplication, META_AUTO_INIT, autoInitEnabled ? 'true' : 'false');
  } else {
    mainApplication = (0, _Manifest().removeMetaDataItemFromMainApplication)(mainApplication, META_AUTO_INIT);
  }

  if (autoLogAppEvents !== null) {
    mainApplication = (0, _Manifest().addMetaDataItemToMainApplication)(mainApplication, META_AUTO_LOG_APP_EVENTS, autoLogAppEvents ? 'true' : 'false');
  } else {
    mainApplication = (0, _Manifest().removeMetaDataItemFromMainApplication)(mainApplication, META_AUTO_LOG_APP_EVENTS);
  }

  if (advertiserIdCollection !== null) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    mainApplication = (0, _Manifest().addMetaDataItemToMainApplication)(mainApplication, META_AD_ID_COLLECTION, advertiserIdCollection ? 'true' : 'false');
  } else {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    mainApplication = (0, _Manifest().removeMetaDataItemFromMainApplication)(mainApplication, META_AD_ID_COLLECTION);
  }

  return androidManifest;
}
//# sourceMappingURL=Facebook.js.map