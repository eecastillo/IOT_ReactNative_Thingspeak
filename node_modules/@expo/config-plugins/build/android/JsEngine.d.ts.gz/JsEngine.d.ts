import type { ExpoConfig } from '@expo/config-types';
import type { ConfigPlugin } from '../Plugin.types';
import type { PropertiesItem } from './Properties';
export declare const JS_ENGINE_PROP_KEY = "expo.jsEngine";
export declare const DEFAULT_JS_ENGINE = "jsc";
export declare const withJsEngineGradleProps: ConfigPlugin;
export declare function getJsEngine(config: Pick<ExpoConfig, 'android'>): "jsc" | "hermes";
export declare function setJsEngine(config: Pick<ExpoConfig, 'android'>, gradleProperties: PropertiesItem[]): PropertiesItem[];
