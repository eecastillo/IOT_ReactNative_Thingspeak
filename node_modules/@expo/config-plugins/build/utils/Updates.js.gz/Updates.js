"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getUpdateUrl = getUpdateUrl;

function getUpdateUrl(config, username) {
  var _config$updates;

  if ((_config$updates = config.updates) !== null && _config$updates !== void 0 && _config$updates.url) {
    var _config$updates2;

    return (_config$updates2 = config.updates) === null || _config$updates2 === void 0 ? void 0 : _config$updates2.url;
  }

  const user = typeof config.owner === 'string' ? config.owner : username;

  if (!user) {
    return null;
  }

  return `https://exp.host/@${user}/${config.slug}`;
}
//# sourceMappingURL=Updates.js.map