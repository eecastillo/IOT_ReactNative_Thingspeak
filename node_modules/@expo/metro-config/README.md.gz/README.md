# expo-metro-config

A Metro config for running React Native projects with the Metro bundler.
