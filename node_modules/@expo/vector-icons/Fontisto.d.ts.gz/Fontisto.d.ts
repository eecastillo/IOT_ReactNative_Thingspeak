import Fontisto from "./build/Fontisto";
export default Fontisto;
