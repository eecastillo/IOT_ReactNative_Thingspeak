import SimpleLineIcons from './build/SimpleLineIcons';
export default SimpleLineIcons;
