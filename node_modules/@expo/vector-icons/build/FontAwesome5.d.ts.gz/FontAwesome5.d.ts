export declare const FA5Style: {
    regular: string;
    light: string;
    solid: string;
    brand: string;
};
declare const iconSet: any;
export default iconSet;
