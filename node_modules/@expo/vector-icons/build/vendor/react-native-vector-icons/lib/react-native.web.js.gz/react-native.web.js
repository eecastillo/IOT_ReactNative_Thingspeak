/* eslint-disable import/no-unresolved */

export * from 'react-native-web';
