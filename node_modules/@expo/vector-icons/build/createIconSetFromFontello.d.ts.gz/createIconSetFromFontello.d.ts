export default function (config: any, expoFontName: any, expoAssetId: any): any;
