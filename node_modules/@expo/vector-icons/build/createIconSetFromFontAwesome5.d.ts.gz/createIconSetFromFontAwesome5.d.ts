export declare const FA5Style: {
    regular: string;
    light: string;
    solid: string;
    brand: string;
};
export declare function createFA5iconSet(glyphMap: any, metadata: {} | undefined, fonts: any, pro?: boolean): any;
