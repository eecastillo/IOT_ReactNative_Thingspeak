import Feather from './build/Feather';
export default Feather;
