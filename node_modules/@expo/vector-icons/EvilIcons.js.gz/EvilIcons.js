import EvilIcons from './build/EvilIcons';
export default EvilIcons;
