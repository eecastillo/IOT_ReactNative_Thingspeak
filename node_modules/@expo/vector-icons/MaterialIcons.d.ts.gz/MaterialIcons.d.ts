import MaterialIcons from './build/MaterialIcons';
export default MaterialIcons;
