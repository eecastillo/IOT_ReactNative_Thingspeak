import FontAwesome from './build/FontAwesome';
export default FontAwesome;
