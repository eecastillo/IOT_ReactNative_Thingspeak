import AntDesign from "./build/AntDesign";
export default AntDesign;
