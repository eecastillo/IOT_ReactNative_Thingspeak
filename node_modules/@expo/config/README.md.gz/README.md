# config

A library for interacting with the `app.json`
