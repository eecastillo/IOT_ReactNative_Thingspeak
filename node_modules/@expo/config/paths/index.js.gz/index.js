module.exports = require('../build/paths');
