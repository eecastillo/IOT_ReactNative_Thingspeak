import { ExpoConfig } from './Config.types';
export declare function getExpoSDKVersion(projectRoot: string, exp: Pick<ExpoConfig, 'sdkVersion'>): string;
