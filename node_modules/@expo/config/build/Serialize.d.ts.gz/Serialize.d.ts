export declare function serializeAndEvaluate(val: any): any;
export declare function serializeSkippingMods(val: any): any;
export declare function serializeAfterStaticPlugins(val: any): any;
