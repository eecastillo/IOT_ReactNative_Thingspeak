export declare function getRootPackageJsonPath(projectRoot: string): string;
