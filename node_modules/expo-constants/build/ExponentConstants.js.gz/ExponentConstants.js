import { NativeModulesProxy } from 'expo-modules-core';
export default NativeModulesProxy.ExponentConstants;
//# sourceMappingURL=ExponentConstants.js.map