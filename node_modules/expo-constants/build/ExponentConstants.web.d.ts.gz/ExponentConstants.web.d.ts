import { NativeConstants } from './Constants.types';
declare const _default: NativeConstants;
export default _default;
