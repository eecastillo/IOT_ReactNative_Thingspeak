import { NativeModulesProxy } from 'expo-modules-core';
export default NativeModulesProxy.ExpoApplication;
//# sourceMappingURL=ExpoApplication.js.map