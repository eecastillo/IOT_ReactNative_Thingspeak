// Copyright 2019-present 650 Industries. All rights reserved.

#import <ExpoModulesCore/EXExportedModule.h>
#import <Foundation/Foundation.h>

@interface EXApplication : EXExportedModule

@end
