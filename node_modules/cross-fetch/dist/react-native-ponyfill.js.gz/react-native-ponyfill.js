module.exports = global.fetch // To enable: import fetch from 'cross-fetch'
module.exports.default = global.fetch // For TypeScript consumers without esModuleInterop.
module.exports.fetch = global.fetch // To enable: import {fetch} from 'cross-fetch'
module.exports.Headers = global.Headers
module.exports.Request = global.Request
module.exports.Response = global.Response
