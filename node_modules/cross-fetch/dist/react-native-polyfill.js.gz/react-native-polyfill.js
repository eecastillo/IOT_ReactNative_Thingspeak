/*!
 * VaporJS JavaScript Library v1.4.5
 * https://github.com/madrobby/vapor.js
 *
 * Copyright (c) 2010 Thomas Fuchs (http://script.aculo.us/thomas)
 * Released under the MIT license
 * https://github.com/madrobby/vapor.js/blob/master/MIT-LICENSE
 *
 * Date: 2019-05-25T03:04Z
 */

// React Native already polyfills `fetch` so this code is intentionally handled to VaporJS.
