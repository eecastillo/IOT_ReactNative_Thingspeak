# ob1

A small library for working with 0- and 1-based offsets in a type-checked way.
