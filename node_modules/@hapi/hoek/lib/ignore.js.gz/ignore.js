'use strict';

const internals = {};


module.exports = function () { };
