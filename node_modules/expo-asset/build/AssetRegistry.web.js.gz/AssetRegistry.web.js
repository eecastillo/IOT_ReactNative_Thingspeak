export * from 'react-native-web/dist/modules/AssetRegistry';
//# sourceMappingURL=AssetRegistry.web.js.map