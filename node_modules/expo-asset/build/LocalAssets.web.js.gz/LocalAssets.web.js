export function getLocalAssetUri(hash, type) {
    // noop on web
    return null;
}
//# sourceMappingURL=LocalAssets.web.js.map