export declare const IS_MANAGED_ENV = false;
export declare const IS_ENV_WITH_UPDATES_ENABLED = false;
export declare const IS_ENV_WITHOUT_UPDATES_ENABLED = false;
export declare const manifestBaseUrl: null;
export declare function downloadAsync(uri: any, hash: any, type: any, name: any): Promise<string>;
export declare function getManifest(): {};
