export * from 'react-native-web/dist/modules/AssetRegistry';
