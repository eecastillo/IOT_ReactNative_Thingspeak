import AssetSourceResolver from 'react-native/Libraries/Image/AssetSourceResolver';
export default AssetSourceResolver;
export * from 'react-native/Libraries/Image/AssetSourceResolver';
