export function getLocalAssetUri(hash: string, type: string | null): string | null {
  // noop on web
  return null;
}
