import resolveAssetSource from 'react-native/Libraries/Image/resolveAssetSource';
export default resolveAssetSource;
export * from 'react-native/Libraries/Image/resolveAssetSource'; // eslint-disable-line import/export
