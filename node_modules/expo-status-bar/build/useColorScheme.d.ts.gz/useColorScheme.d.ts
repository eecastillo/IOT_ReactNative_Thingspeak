import { useColorScheme as maybeUseColorScheme } from 'react-native';
declare const useColorScheme: typeof maybeUseColorScheme;
export default useColorScheme;
