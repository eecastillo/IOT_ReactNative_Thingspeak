import { StatusBarStyle } from './StatusBar.types';
export default function setStatusBarStyle(style: StatusBarStyle): void;
