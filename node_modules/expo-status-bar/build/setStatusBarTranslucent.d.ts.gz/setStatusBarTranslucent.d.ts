export default function setStatusBarTranslucent(translucent: boolean): void;
