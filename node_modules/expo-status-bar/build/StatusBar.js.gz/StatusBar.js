export * from './StatusBar.types';
export { default as setStatusBarBackgroundColor } from './setStatusBarBackgroundColor';
export { default as setStatusBarNetworkActivityIndicatorVisible } from './setStatusBarNetworkActivityIndicatorVisible';
export { default as setStatusBarHidden } from './setStatusBarHidden';
export { default as setStatusBarStyle } from './setStatusBarStyle';
export { default as setStatusBarTranslucent } from './setStatusBarTranslucent';
export { default as StatusBar } from './ExpoStatusBar';
//# sourceMappingURL=StatusBar.js.map