import { StatusBar } from 'react-native';
export default function setStatusBarHidden(hidden, animation) {
    StatusBar.setHidden(hidden, animation);
}
//# sourceMappingURL=setStatusBarHidden.js.map