// StatusBar does nothing on web currently
export default function ExpoStatusBar(props) {
    return null;
}
//# sourceMappingURL=ExpoStatusBar.js.map