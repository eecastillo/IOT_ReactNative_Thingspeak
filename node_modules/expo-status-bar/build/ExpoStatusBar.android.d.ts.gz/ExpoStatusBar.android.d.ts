import { StatusBarProps } from './StatusBar.types';
export default function ExpoStatusBar(props: StatusBarProps): JSX.Element;
