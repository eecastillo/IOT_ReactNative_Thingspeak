import { StatusBar } from 'react-native';
export default function setStatusBarTranslucent(translucent) {
    StatusBar.setTranslucent(translucent);
}
//# sourceMappingURL=setStatusBarTranslucent.js.map