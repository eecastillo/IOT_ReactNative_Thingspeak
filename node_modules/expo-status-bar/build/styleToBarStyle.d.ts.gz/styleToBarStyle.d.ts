import { ColorSchemeName } from 'react-native';
import { StatusBarStyle } from './StatusBar.types';
export default function styleToBarStyle(style?: StatusBarStyle, colorScheme?: ColorSchemeName): 'light-content' | 'dark-content';
