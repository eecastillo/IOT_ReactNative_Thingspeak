export default function setStatusBarBackgroundColor(backgroundColor: string, animated: boolean): void;
