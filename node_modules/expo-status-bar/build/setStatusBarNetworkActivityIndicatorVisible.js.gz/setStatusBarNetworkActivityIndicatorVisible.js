import { StatusBar } from 'react-native';
export default function setStatusBarNetworkActivityIndicatorVisible(visible) {
    StatusBar.setNetworkActivityIndicatorVisible(visible);
}
//# sourceMappingURL=setStatusBarNetworkActivityIndicatorVisible.js.map