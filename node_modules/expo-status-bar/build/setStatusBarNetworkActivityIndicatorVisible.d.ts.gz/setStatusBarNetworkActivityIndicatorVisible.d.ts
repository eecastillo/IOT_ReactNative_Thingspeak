export default function setStatusBarNetworkActivityIndicatorVisible(visible: boolean): void;
