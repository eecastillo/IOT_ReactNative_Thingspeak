import { StatusBar } from 'react-native';
export default function setStatusBarBackgroundColor(backgroundColor, animated) {
    StatusBar.setBackgroundColor(backgroundColor, animated);
}
//# sourceMappingURL=setStatusBarBackgroundColor.js.map