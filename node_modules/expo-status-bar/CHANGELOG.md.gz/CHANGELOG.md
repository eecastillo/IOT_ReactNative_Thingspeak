# Changelog

## Unpublished

### 🛠 Breaking changes

### 🎉 New features

### 🐛 Bug fixes

### 💡 Others

## 1.1.0 — 2021-09-09

_This version does not introduce any user-facing changes._

## 1.0.4 — 2021-03-10

_This version does not introduce any user-facing changes._

## 1.0.3 — 2020-11-17

_This version does not introduce any user-facing changes._

## 1.0.2 — 2020-06-25

### 🐛 Bug fixes

- Provide web fallback for styleToBarStyle in order to not produce a warning.
