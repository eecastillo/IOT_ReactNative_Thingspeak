import { StatusBarProps } from './StatusBar.types';

// StatusBar does nothing on web currently
export default function ExpoStatusBar(props: StatusBarProps) {
  return null;
}
