import * as React from 'react';
import type { StackCardInterpolationProps } from '../types';

export default React.createContext<StackCardInterpolationProps | undefined>(
  undefined
);
