import type { GestureDirection } from '../types';
export default function getInvertedMultiplier(gestureDirection: GestureDirection): 1 | -1;
