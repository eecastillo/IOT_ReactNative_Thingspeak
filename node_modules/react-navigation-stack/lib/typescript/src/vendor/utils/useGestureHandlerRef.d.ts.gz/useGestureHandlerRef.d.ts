/// <reference types="react-native-gesture-handler" />
import * as React from 'react';
export default function useGestureHandlerRef(): React.Ref<import("react-native-gesture-handler").PanGestureHandler>;
