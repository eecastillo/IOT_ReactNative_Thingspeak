import type { GestureDirection, Layout } from '../types';
export default function getDistanceForDirection(layout: Layout, gestureDirection: GestureDirection): number;
