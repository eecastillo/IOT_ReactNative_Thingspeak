import * as React from 'react';
import type { Scene } from '../types';
declare const PreviousSceneContext: React.Context<Scene<import("react-navigation").NavigationRoute<import("react-navigation").NavigationParams>> | undefined>;
export default PreviousSceneContext;
