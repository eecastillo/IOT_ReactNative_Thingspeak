export default function useCardAnimation(): import("..").StackCardInterpolationProps;
