export default function useFloatingHeaderHeight(): number;
