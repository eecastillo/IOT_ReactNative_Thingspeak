/// <reference types="react-native-gesture-handler" />
import * as React from 'react';
declare const _default: React.Context<React.Ref<import("react-native-gesture-handler").PanGestureHandler>>;
export default _default;
