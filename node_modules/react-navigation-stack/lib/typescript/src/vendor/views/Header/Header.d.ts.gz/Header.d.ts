import * as React from 'react';
import type { StackHeaderProps } from '../../types';
declare const Header: React.NamedExoticComponent<StackHeaderProps>;
export default Header;
