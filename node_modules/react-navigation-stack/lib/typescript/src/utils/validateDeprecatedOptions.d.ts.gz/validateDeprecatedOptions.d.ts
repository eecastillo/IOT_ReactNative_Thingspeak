import type { StackNavigationOptions } from '../vendor/types';
export default function validateDeprecatedOptions(options: StackNavigationOptions): StackNavigationOptions;
