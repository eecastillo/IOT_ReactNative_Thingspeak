import type { StackNavigationOptions, StackNavigationConfig } from '../vendor/types';
export default function validateDeprecatedConfig(config: StackNavigationConfig, options: StackNavigationOptions): StackNavigationOptions;
