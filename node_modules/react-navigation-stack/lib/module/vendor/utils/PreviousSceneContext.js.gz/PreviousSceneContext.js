import * as React from 'react';
const PreviousSceneContext = /*#__PURE__*/React.createContext(undefined);
export default PreviousSceneContext;
//# sourceMappingURL=PreviousSceneContext.js.map