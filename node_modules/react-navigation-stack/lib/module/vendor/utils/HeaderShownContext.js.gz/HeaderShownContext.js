import * as React from 'react';
const HeaderShownContext = /*#__PURE__*/React.createContext(false);
export default HeaderShownContext;
//# sourceMappingURL=HeaderShownContext.js.map