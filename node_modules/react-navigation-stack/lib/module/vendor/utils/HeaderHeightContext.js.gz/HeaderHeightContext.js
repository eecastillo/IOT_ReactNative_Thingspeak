import * as React from 'react';
export default /*#__PURE__*/React.createContext(undefined);
//# sourceMappingURL=HeaderHeightContext.js.map