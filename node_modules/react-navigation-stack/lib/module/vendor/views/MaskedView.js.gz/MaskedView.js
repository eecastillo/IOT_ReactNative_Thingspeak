/**
 * Use a stub for MaskedView on all Platforms that don't support it.
 */
export default function MaskedView({
  children
}) {
  return children;
}
//# sourceMappingURL=MaskedView.js.map