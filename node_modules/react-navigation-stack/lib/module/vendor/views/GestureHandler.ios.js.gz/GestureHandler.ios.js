export * from './GestureHandlerNative';
//# sourceMappingURL=GestureHandler.ios.js.map