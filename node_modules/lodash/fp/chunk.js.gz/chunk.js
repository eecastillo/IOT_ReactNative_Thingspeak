var convert = require('./convert'),
    func = convert('chunk', require('../chunk'));

func.placeholder = require('./placeholder');
module.exports = func;
