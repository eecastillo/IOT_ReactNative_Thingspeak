module.exports = require('./isEqual');
