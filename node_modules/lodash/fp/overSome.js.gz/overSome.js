var convert = require('./convert'),
    func = convert('overSome', require('../overSome'));

func.placeholder = require('./placeholder');
module.exports = func;
