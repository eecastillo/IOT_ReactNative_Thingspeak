import MaskedView from './js/MaskedView';

export default MaskedView;
