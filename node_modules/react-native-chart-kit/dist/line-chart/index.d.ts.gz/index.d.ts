import LineChart from "./LineChart";
export default LineChart;
//# sourceMappingURL=index.d.ts.map