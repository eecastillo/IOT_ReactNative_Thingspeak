export declare function shiftDate(date: Date, numDays: number): Date;
export declare function getBeginningTimeForDate(date: Date): Date;
export declare function convertToDate(obj: string | number | Date): Date;
//# sourceMappingURL=DateHelpers.d.ts.map