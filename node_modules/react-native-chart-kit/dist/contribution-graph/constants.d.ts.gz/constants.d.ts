export declare const MILLISECONDS_IN_ONE_DAY: number;
export declare const DAYS_IN_WEEK = 7;
export declare const MONTH_LABELS: {
    0: string;
    1: string;
    2: string;
    3: string;
    4: string;
    5: string;
    6: string;
    7: string;
    8: string;
    9: string;
    10: string;
    11: string;
};
//# sourceMappingURL=constants.d.ts.map