export declare function mapValue(x: number, in_min: number, in_max: number, out_min: number, out_max: number): number;
//# sourceMappingURL=Utils.d.ts.map