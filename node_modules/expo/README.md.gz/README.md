# expo

The `expo` package is an umbrella package that contains the client-side code (ex: JavaScript) for accessing system functionality such as contacts, camera, and location in Expo apps.

Some of the Expo APIs are implemented in this package, while others are implemented in universal modules under the parent `packages` directory.

See [CONTRIBUTING](./CONTRIBUTING.md) for instructions on working on this package and the universal modules.
