import './environment/validate.fx';
import './environment/logging.fx';
import './environment/react-native-logs.fx';
import 'expo-asset';
