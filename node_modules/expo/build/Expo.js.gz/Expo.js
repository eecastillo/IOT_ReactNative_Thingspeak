import './Expo.fx';
import * as Logs from './logs/Logs';
export { Logs };
export { default as registerRootComponent } from './launch/registerRootComponent';
//# sourceMappingURL=Expo.js.map