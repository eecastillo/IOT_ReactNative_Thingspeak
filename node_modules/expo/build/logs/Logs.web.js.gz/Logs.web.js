export function enableExpoCliLogging() {
    console.warn('Expo.Logs.enableExpoCliLogging: is not supported on web');
}
export function disableExpoCliLogging() {
    console.warn('Expo.Logs.disableExpoCliLogging: is not supported on web');
}
//# sourceMappingURL=Logs.web.js.map