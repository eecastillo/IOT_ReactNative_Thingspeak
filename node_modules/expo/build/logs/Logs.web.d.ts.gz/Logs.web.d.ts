export declare function enableExpoCliLogging(): void;
export declare function disableExpoCliLogging(): void;
