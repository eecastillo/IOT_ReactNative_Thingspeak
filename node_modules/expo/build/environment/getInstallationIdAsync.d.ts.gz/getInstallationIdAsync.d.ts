export default function getInstallationIdAsync(): Promise<string>;
