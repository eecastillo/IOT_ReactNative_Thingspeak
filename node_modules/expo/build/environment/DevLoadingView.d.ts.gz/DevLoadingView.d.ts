export default function DevLoadingView(): JSX.Element | null;
