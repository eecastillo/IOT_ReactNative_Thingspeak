import * as React from 'react';
export default class DevAppContainer extends React.Component {
    render(): JSX.Element;
}
