/**
 * @param value Should 'expo' validate the environment against Constants.expoVersion
 */
export declare function _setShouldThrowAnErrorOutsideOfExpo(value: any): void;
/**
 * Should 'expo' validate the environment against Constants.expoVersion
 */
export declare function shouldThrowAnErrorOutsideOfExpo(): boolean;
