export default function getInstallationIdAsync(): string;
