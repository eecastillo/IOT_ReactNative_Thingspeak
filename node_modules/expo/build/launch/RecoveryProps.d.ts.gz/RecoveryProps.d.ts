import { InitialProps } from './withExpoRoot.types';
export declare const attachRecoveredProps: <P extends InitialProps>(props: P) => P;
