export {};
//# sourceMappingURL=withExpoRoot.types.js.map