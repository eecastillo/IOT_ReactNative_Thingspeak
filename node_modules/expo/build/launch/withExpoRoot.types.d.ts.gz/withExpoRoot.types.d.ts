export declare type InitialProps = {
    exp: {
        notification?: any;
        errorRecovery?: any;
        manifestString?: string;
        [key: string]: any;
    };
    shell?: boolean;
    shellManifestUrl?: string;
    [key: string]: any;
};
