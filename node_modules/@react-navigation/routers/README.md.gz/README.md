# `@react-navigation/routers`

Routers to help build custom navigators.

You probably don't need to use this package directly if you're not building custom navigators.

## Installation

Open a Terminal in your project's folder and run,

```sh
yarn add @react-navigation/routers
```

## Usage

Documentation can be found on the [React Navigation website](https://reactnavigation.org/docs/custom-routers/).
