import * as React from 'react';

const ModalPresentationContext = React.createContext(false);

export default ModalPresentationContext;
