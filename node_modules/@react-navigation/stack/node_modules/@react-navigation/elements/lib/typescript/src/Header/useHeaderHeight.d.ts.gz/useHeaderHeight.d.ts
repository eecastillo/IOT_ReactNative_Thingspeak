export default function useHeaderHeight(): number;
