/// <reference types="react" />
declare const HeaderHeightContext: import("react").Context<number | undefined>;
export default HeaderHeightContext;
