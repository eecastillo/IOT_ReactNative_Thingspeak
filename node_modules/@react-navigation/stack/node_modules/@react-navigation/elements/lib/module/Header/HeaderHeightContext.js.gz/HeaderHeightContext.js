import getNamedContext from '../getNamedContext';
const HeaderHeightContext = getNamedContext('HeaderHeightContext', undefined);
export default HeaderHeightContext;
//# sourceMappingURL=HeaderHeightContext.js.map