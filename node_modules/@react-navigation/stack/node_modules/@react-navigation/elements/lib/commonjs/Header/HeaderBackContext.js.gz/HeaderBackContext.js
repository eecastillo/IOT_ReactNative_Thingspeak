"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _getNamedContext = _interopRequireDefault(require("../getNamedContext"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const HeaderBackContext = (0, _getNamedContext.default)('HeaderBackContext', undefined);
var _default = HeaderBackContext;
exports.default = _default;
//# sourceMappingURL=HeaderBackContext.js.map