export { default } from './MaskedViewNative';
