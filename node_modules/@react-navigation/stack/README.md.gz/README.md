# `@react-navigation/stack`

Stack navigator for React Navigation.

Installation instructions and documentation can be found on the [React Navigation website](https://reactnavigation.org/docs/stack-navigator/).
