import * as React from 'react';
declare const ModalPresentationContext: React.Context<boolean>;
export default ModalPresentationContext;
