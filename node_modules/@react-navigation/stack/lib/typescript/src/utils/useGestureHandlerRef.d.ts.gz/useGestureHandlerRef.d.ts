import * as React from 'react';
export default function useGestureHandlerRef(): React.Ref<React.ComponentType<import("react-native-gesture-handler").PanGestureHandlerProps & React.RefAttributes<any>>>;
