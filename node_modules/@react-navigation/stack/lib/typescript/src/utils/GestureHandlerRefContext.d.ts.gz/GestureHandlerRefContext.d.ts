import * as React from 'react';
declare const _default: React.Context<React.Ref<React.ComponentType<import("react-native-gesture-handler").PanGestureHandlerProps & React.RefAttributes<any>>>>;
export default _default;
