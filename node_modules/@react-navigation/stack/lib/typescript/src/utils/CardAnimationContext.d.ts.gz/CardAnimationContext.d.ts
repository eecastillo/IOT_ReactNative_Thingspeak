import * as React from 'react';
import type { StackCardInterpolationProps } from '../types';
declare const _default: React.Context<StackCardInterpolationProps | undefined>;
export default _default;
