import * as React from 'react';
import type { StackHeaderProps } from '../../types';
declare const _default: React.NamedExoticComponent<StackHeaderProps>;
export default _default;
