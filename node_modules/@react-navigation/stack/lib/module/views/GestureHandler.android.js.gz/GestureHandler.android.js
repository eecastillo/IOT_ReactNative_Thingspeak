export * from './GestureHandlerNative';
//# sourceMappingURL=GestureHandler.android.js.map