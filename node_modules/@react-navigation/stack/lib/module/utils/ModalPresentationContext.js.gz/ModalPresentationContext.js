import * as React from 'react';
const ModalPresentationContext = /*#__PURE__*/React.createContext(false);
export default ModalPresentationContext;
//# sourceMappingURL=ModalPresentationContext.js.map