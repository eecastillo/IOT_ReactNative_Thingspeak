"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "createNativeStackNavigator", {
  enumerable: true,
  get: function () {
    return _createNativeStackNavigator.default;
  }
});

var _createNativeStackNavigator = _interopRequireDefault(require("./navigators/createNativeStackNavigator"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=index.js.map