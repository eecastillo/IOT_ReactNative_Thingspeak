"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.processFonts = processFonts;

function processFonts(_) {
  throw new Error('Not supported on Web');
}
//# sourceMappingURL=FontProcessor.js.map