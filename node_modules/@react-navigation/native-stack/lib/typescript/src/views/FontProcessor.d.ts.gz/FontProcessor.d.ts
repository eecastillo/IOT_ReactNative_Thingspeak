export declare function processFonts(_: (string | undefined)[]): (string | undefined)[];
