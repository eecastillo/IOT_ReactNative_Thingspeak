export declare function processFonts(fontFamilies: (string | undefined)[]): (string | undefined)[];
