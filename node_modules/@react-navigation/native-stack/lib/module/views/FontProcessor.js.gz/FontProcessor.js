export function processFonts(_) {
  throw new Error('Not supported on Web');
}
//# sourceMappingURL=FontProcessor.js.map