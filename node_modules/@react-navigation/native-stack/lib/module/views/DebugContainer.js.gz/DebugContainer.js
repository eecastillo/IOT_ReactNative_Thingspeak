import * as React from 'react';
import { View } from 'react-native';
export default function Container(props) {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const {
    stackPresentation: _,
    ...rest
  } = props;
  return /*#__PURE__*/React.createElement(View, rest);
}
//# sourceMappingURL=DebugContainer.js.map