/**
 * Navigators
 */
export { default as createNativeStackNavigator } from './navigators/createNativeStackNavigator';
/**
 * Types
 */
//# sourceMappingURL=index.js.map