import getNamedContext from '../getNamedContext';
const HeaderBackContext = getNamedContext('HeaderBackContext', undefined);
export default HeaderBackContext;
//# sourceMappingURL=HeaderBackContext.js.map