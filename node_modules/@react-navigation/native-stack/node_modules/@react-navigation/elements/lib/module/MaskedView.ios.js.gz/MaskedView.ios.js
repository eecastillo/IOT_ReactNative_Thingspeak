export { default } from './MaskedViewNative';
//# sourceMappingURL=MaskedView.ios.js.map