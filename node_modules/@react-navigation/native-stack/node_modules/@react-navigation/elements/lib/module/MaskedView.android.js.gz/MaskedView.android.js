export { default } from './MaskedViewNative';
//# sourceMappingURL=MaskedView.android.js.map