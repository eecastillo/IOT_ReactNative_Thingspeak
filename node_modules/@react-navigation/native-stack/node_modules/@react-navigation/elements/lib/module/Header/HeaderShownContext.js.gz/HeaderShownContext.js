import getNamedContext from '../getNamedContext';
const HeaderShownContext = getNamedContext('HeaderShownContext', false);
export default HeaderShownContext;
//# sourceMappingURL=HeaderShownContext.js.map