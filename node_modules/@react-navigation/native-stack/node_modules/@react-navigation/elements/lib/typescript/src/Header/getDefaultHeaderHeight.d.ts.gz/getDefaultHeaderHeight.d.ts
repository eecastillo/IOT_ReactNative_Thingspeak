import type { Layout } from '../types';
export default function getDefaultHeaderHeight(layout: Layout, modalPresentation: boolean, statusBarHeight: number): number;
