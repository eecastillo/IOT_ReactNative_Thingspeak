/// <reference types="react" />
declare const HeaderBackContext: import("react").Context<{
    title: string;
} | undefined>;
export default HeaderBackContext;
