"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Group;

/**
 * Empty component used for grouping screen configs.
 */
function Group(_) {
  /* istanbul ignore next */
  return null;
}
//# sourceMappingURL=Group.js.map