"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Screen;

/**
 * Empty component used for specifying route configuration.
 */
function Screen(_) {
  /* istanbul ignore next */
  return null;
}
//# sourceMappingURL=Screen.js.map