import type { Route } from '@react-navigation/routers';
export default function getFocusedRouteNameFromRoute(route: Partial<Route<string>>): string | undefined;
