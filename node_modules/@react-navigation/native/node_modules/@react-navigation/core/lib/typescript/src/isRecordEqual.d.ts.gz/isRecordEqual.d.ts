/**
 * Compare two records with primitive values as the content.
 */
export default function isRecordEqual(a: Record<string, any>, b: Record<string, any>): boolean;
