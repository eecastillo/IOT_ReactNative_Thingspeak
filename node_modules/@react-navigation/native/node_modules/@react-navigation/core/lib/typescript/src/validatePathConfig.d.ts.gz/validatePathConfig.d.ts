export default function validatePathConfig(config: any, root?: boolean): void;
