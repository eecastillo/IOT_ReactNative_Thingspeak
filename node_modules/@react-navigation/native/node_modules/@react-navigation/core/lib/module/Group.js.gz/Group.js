/**
 * Empty component used for grouping screen configs.
 */
export default function Group(_) {
  /* istanbul ignore next */
  return null;
}
//# sourceMappingURL=Group.js.map