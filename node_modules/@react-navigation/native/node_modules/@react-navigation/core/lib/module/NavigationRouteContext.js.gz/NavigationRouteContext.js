import * as React from 'react';
/**
 * Context which holds the route prop for a screen.
 */

const NavigationRouteContext = /*#__PURE__*/React.createContext(undefined);
export default NavigationRouteContext;
//# sourceMappingURL=NavigationRouteContext.js.map