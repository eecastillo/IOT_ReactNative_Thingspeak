/**
 * Empty component used for specifying route configuration.
 */
export default function Screen(_) {
  /* istanbul ignore next */
  return null;
}
//# sourceMappingURL=Screen.js.map