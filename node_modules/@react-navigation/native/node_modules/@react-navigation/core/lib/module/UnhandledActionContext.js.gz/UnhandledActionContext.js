import * as React from 'react';
const UnhandledActionContext = /*#__PURE__*/React.createContext(undefined);
export default UnhandledActionContext;
//# sourceMappingURL=UnhandledActionContext.js.map