import * as React from 'react';
const LinkingContext = /*#__PURE__*/React.createContext({
  options: undefined
});
LinkingContext.displayName = 'LinkingContext';
export default LinkingContext;
//# sourceMappingURL=LinkingContext.js.map