import * as React from 'react';
const ServerContext = /*#__PURE__*/React.createContext(undefined);
export default ServerContext;
//# sourceMappingURL=ServerContext.js.map