import type { Theme } from '../types';
declare const DarkTheme: Theme;
export default DarkTheme;
