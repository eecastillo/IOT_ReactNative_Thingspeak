export default function useTheme(): import("..").Theme;
