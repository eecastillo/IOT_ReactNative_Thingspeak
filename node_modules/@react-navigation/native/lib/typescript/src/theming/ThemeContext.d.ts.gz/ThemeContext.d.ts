import * as React from 'react';
import type { Theme } from '../types';
declare const ThemeContext: React.Context<Theme>;
export default ThemeContext;
