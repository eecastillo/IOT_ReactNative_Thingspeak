export default function useDocumentTitle(): void;
