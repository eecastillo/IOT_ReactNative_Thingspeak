export default function extractPathFromURL(prefixes: string[], url: string): string | undefined;
