"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = useDocumentTitle;

function useDocumentTitle() {// Noop for React Native
}
//# sourceMappingURL=useDocumentTitle.native.js.map