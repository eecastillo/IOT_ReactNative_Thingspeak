export default function useDocumentTitle() {
  // Noop for React Native
}
