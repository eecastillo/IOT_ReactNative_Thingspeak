# `@react-navigation/native`

React Native integration for React Navigation.

Installation instructions and documentation can be found on the [React Navigation website](https://reactnavigation.org/docs/getting-started/).
