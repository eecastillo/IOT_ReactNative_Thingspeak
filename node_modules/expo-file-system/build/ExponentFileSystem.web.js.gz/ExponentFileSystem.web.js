import ExponentFileSystemShim from './ExponentFileSystemShim';
export default ExponentFileSystemShim;
//# sourceMappingURL=ExponentFileSystem.web.js.map