import { ExponentFileSystemModule } from './FileSystem.types';
declare const platformModule: ExponentFileSystemModule;
export default platformModule;
