import { ExponentFileSystemModule } from './FileSystem.types';
declare const _default: ExponentFileSystemModule;
export default _default;
