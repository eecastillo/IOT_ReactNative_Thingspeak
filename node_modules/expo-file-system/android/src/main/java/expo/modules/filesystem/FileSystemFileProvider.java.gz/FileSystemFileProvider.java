package expo.modules.filesystem;

import androidx.core.content.FileProvider;

public class FileSystemFileProvider extends FileProvider {}
