"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getAndroidPermissions = getAndroidPermissions;
exports.setAndroidPermissions = setAndroidPermissions;
exports.isPermissionAlreadyRequested = isPermissionAlreadyRequested;
exports.addPermissionToManifest = addPermissionToManifest;
exports.removePermissions = removePermissions;
exports.addPermission = addPermission;
exports.ensurePermissions = ensurePermissions;
exports.ensurePermission = ensurePermission;
exports.ensurePermissionNameFormat = ensurePermissionNameFormat;
exports.getPermissions = getPermissions;
exports.withPermissions = void 0;

function _androidPlugins() {
  const data = require("../plugins/android-plugins");

  _androidPlugins = function () {
    return data;
  };

  return data;
}

const USES_PERMISSION = 'uses-permission';

const withPermissions = (config, permissions) => {
  if (Array.isArray(permissions)) {
    permissions = permissions.filter(Boolean);
    if (!config.android) config.android = {};
    if (!config.android.permissions) config.android.permissions = [];
    config.android.permissions = [// @ts-ignore
    ...new Set(config.android.permissions.concat(permissions))];
  }

  return (0, _androidPlugins().withAndroidManifest)(config, async config => {
    config.modResults = await setAndroidPermissions(config, config.modResults);
    return config;
  });
};

exports.withPermissions = withPermissions;

function prefixAndroidPermissionsIfNecessary(permissions) {
  return permissions.map(permission => {
    if (!permission.includes('.')) {
      return `android.permission.${permission}`;
    }

    return permission;
  });
}

function getAndroidPermissions(config) {
  var _config$android$permi, _config$android;

  return (_config$android$permi = (_config$android = config.android) === null || _config$android === void 0 ? void 0 : _config$android.permissions) !== null && _config$android$permi !== void 0 ? _config$android$permi : [];
}

function setAndroidPermissions(config, androidManifest) {
  var _androidManifest$mani;

  const permissions = getAndroidPermissions(config);
  const providedPermissions = prefixAndroidPermissionsIfNecessary(permissions);
  const permissionsToAdd = [...providedPermissions];

  if (!androidManifest.manifest.hasOwnProperty('uses-permission')) {
    androidManifest.manifest['uses-permission'] = [];
  } // manifest.manifest['uses-permission'] = [];


  const manifestPermissions = (_androidManifest$mani = androidManifest.manifest['uses-permission']) !== null && _androidManifest$mani !== void 0 ? _androidManifest$mani : [];
  permissionsToAdd.forEach(permission => {
    if (!isPermissionAlreadyRequested(permission, manifestPermissions)) {
      addPermissionToManifest(permission, manifestPermissions);
    }
  });
  return androidManifest;
}

function isPermissionAlreadyRequested(permission, manifestPermissions) {
  return manifestPermissions.some(e => e.$['android:name'] === permission);
}

function addPermissionToManifest(permission, manifestPermissions) {
  manifestPermissions.push({
    $: {
      'android:name': permission
    }
  });
  return manifestPermissions;
}

function removePermissions(androidManifest, permissionNames) {
  const targetNames = permissionNames ? permissionNames.map(ensurePermissionNameFormat) : null;
  const permissions = androidManifest.manifest[USES_PERMISSION] || [];
  const nextPermissions = [];

  for (const attribute of permissions) {
    if (targetNames) {
      // @ts-ignore: name isn't part of the type
      const value = attribute.$['android:name'] || attribute.$.name;

      if (!targetNames.includes(value)) {
        nextPermissions.push(attribute);
      }
    }
  }

  androidManifest.manifest[USES_PERMISSION] = nextPermissions;
}

function addPermission(androidManifest, permissionName) {
  const usesPermissions = androidManifest.manifest[USES_PERMISSION] || [];
  usesPermissions.push({
    $: {
      'android:name': permissionName
    }
  });
  androidManifest.manifest[USES_PERMISSION] = usesPermissions;
}

function ensurePermissions(androidManifest, permissionNames) {
  const permissions = getPermissions(androidManifest);
  const results = {};

  for (const permissionName of permissionNames) {
    const targetName = ensurePermissionNameFormat(permissionName);

    if (!permissions.includes(targetName)) {
      addPermission(androidManifest, targetName);
      results[permissionName] = true;
    } else {
      results[permissionName] = false;
    }
  }

  return results;
}

function ensurePermission(androidManifest, permissionName) {
  const permissions = getPermissions(androidManifest);
  const targetName = ensurePermissionNameFormat(permissionName);

  if (!permissions.includes(targetName)) {
    addPermission(androidManifest, targetName);
    return true;
  }

  return false;
}

function ensurePermissionNameFormat(permissionName) {
  if (permissionName.includes('.')) {
    const com = permissionName.split('.');
    const name = com.pop();
    return [...com, name.toUpperCase()].join('.');
  } else {
    // If shorthand form like `WRITE_CONTACTS` is provided, expand it to `android.permission.WRITE_CONTACTS`.
    return ensurePermissionNameFormat(`android.permission.${permissionName}`);
  }
}

function getPermissions(androidManifest) {
  const usesPermissions = androidManifest.manifest[USES_PERMISSION] || [];
  const permissions = usesPermissions.map(permissionObject => {
    return permissionObject.$['android:name'] || permissionObject.$.name;
  });
  return permissions;
}
//# sourceMappingURL=Permissions.js.map