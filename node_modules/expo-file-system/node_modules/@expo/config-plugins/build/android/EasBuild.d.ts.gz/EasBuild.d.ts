export declare function getEasBuildGradlePath(projectRoot: string): string;
export declare function configureEasBuildAsync(projectRoot: string): Promise<void>;
export declare function isEasBuildGradleConfiguredAsync(projectRoot: string): Promise<boolean>;
