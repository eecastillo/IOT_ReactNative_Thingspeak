"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getUpdateUrl = getUpdateUrl;
exports.getNativeVersion = getNativeVersion;
exports.getRuntimeVersion = getRuntimeVersion;
exports.withRuntimeVersion = void 0;

function _sdkRuntimeVersions() {
  const data = require("@expo/sdk-runtime-versions");

  _sdkRuntimeVersions = function () {
    return data;
  };

  return data;
}

function _() {
  const data = require("..");

  _ = function () {
    return data;
  };

  return data;
}

function getUpdateUrl(config, username) {
  var _config$updates;

  if ((_config$updates = config.updates) !== null && _config$updates !== void 0 && _config$updates.url) {
    var _config$updates2;

    return (_config$updates2 = config.updates) === null || _config$updates2 === void 0 ? void 0 : _config$updates2.url;
  }

  const user = typeof config.owner === 'string' ? config.owner : username;

  if (!user) {
    return null;
  }

  return `https://exp.host/@${user}/${config.slug}`;
}

function getNativeVersion(config, platform) {
  const version = _().IOSConfig.Version.getVersion(config);

  switch (platform) {
    case 'ios':
      {
        const buildNumber = _().IOSConfig.Version.getBuildNumber(config);

        return `${version}(${buildNumber})`;
      }

    case 'android':
      {
        const versionCode = _().AndroidConfig.Version.getVersionCode(config);

        return `${version}(${versionCode})`;
      }

    default:
      {
        throw new Error(`"${platform}" is not a supported platform. Choose either "ios" or "android".`);
      }
  }
}
/**
 * Compute runtime version policies.
 * @return an expoConfig with only string valued platform specific runtime versions.
 */


const withRuntimeVersion = config => {
  var _config$ios, _config$android;

  if ((_config$ios = config.ios) !== null && _config$ios !== void 0 && _config$ios.runtimeVersion || config.runtimeVersion) {
    config.ios = { ...config.ios,
      runtimeVersion: getRuntimeVersion(config, 'ios')
    };
  }

  if ((_config$android = config.android) !== null && _config$android !== void 0 && _config$android.runtimeVersion || config.runtimeVersion) {
    config.android = { ...config.android,
      runtimeVersion: getRuntimeVersion(config, 'android')
    };
  }

  delete config.runtimeVersion;
  return config;
};

exports.withRuntimeVersion = withRuntimeVersion;

function getRuntimeVersion(config, platform) {
  var _config$platform$runt, _config$platform;

  const runtimeVersion = (_config$platform$runt = (_config$platform = config[platform]) === null || _config$platform === void 0 ? void 0 : _config$platform.runtimeVersion) !== null && _config$platform$runt !== void 0 ? _config$platform$runt : config.runtimeVersion;

  if (!runtimeVersion) {
    throw new Error(`There is neither a value or a policy set for the runtime version on "${platform}"`);
  }

  if (typeof runtimeVersion === 'string') {
    return runtimeVersion;
  } else if (runtimeVersion.policy === 'nativeVersion') {
    return getNativeVersion(config, platform);
  } else if (runtimeVersion.policy === 'sdkVersion') {
    if (!config.sdkVersion) {
      throw new Error("An SDK version must be defined when using the 'sdkVersion' runtime policy.");
    }

    return (0, _sdkRuntimeVersions().getRuntimeVersionForSDKVersion)(config.sdkVersion);
  }

  throw new Error(`"${typeof runtimeVersion === 'object' ? JSON.stringify(runtimeVersion) : runtimeVersion}" is not a valid runtime version. getRuntimeVersion only supports a string, "sdkVersion", or "nativeVersion" policy.`);
}
//# sourceMappingURL=Updates.js.map