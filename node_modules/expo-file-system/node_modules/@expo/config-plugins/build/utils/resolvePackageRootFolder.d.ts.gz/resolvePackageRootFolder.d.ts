export declare function resolvePackageRootFolder(fromDirectory: string, moduleId: string): string | null;
