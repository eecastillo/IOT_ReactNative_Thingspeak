"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getXCBuildConfigurationFromPbxproj = getXCBuildConfigurationFromPbxproj;
exports.findApplicationTargetWithDependenciesAsync = findApplicationTargetWithDependenciesAsync;
exports.isTargetOfType = isTargetOfType;
exports.getNativeTargets = getNativeTargets;
exports.findSignableTargets = findSignableTargets;
exports.findFirstNativeTarget = findFirstNativeTarget;
exports.findNativeTargetByName = findNativeTargetByName;
exports.TargetType = void 0;

function _BuildScheme() {
  const data = require("./BuildScheme");

  _BuildScheme = function () {
    return data;
  };

  return data;
}

function _Xcodeproj() {
  const data = require("./utils/Xcodeproj");

  _Xcodeproj = function () {
    return data;
  };

  return data;
}

let TargetType;
exports.TargetType = TargetType;

(function (TargetType) {
  TargetType["APPLICATION"] = "com.apple.product-type.application";
  TargetType["EXTENSION"] = "com.apple.product-type.app-extension";
  TargetType["WATCH"] = "com.apple.product-type.application.watchapp";
  TargetType["STICKER_PACK_EXTENSION"] = "com.apple.product-type.app-extension.messages-sticker-pack";
  TargetType["OTHER"] = "other";
})(TargetType || (exports.TargetType = TargetType = {}));

function getXCBuildConfigurationFromPbxproj(project, {
  targetName,
  buildConfiguration = 'Release'
} = {}) {
  const [, nativeTarget] = targetName ? findNativeTargetByName(project, targetName) : findFirstNativeTarget(project);
  const [, xcBuildConfiguration] = (0, _Xcodeproj().getBuildConfigurationForListIdAndName)(project, {
    configurationListId: nativeTarget.buildConfigurationList,
    buildConfiguration
  });
  return xcBuildConfiguration !== null && xcBuildConfiguration !== void 0 ? xcBuildConfiguration : null;
}

async function findApplicationTargetWithDependenciesAsync(projectRoot, scheme) {
  const applicationTargetName = await (0, _BuildScheme().getApplicationTargetNameForSchemeAsync)(projectRoot, scheme);
  const project = (0, _Xcodeproj().getPbxproj)(projectRoot);
  const [, applicationTarget] = findNativeTargetByName(project, applicationTargetName);
  const dependencies = applicationTarget.dependencies.map(({
    value
  }) => {
    const {
      target: targetId
    } = project.getPBXGroupByKeyAndType(value, 'PBXTargetDependency');
    const [, target] = findNativeTargetById(project, targetId);
    const type = isTargetOfType(target, TargetType.EXTENSION) ? TargetType.EXTENSION : TargetType.OTHER;
    return {
      name: target.name,
      type
    };
  });
  return {
    name: applicationTarget.name,
    type: TargetType.APPLICATION,
    dependencies
  };
}

function isTargetOfType(target, targetType) {
  return target.productType === targetType || target.productType === `"${targetType}"`;
}

function getNativeTargets(project) {
  const section = project.pbxNativeTargetSection();
  return Object.entries(section).filter(_Xcodeproj().isNotComment);
}

function findSignableTargets(project) {
  const targets = getNativeTargets(project);
  const applicationTargets = targets.filter(([, target]) => isTargetOfType(target, TargetType.APPLICATION) || isTargetOfType(target, TargetType.EXTENSION) || isTargetOfType(target, TargetType.WATCH) || isTargetOfType(target, TargetType.STICKER_PACK_EXTENSION));

  if (applicationTargets.length === 0) {
    throw new Error(`Could not find any signable targets in project.pbxproj`);
  }

  return applicationTargets;
}

function findFirstNativeTarget(project) {
  const targets = getNativeTargets(project);
  const applicationTargets = targets.filter(([, target]) => isTargetOfType(target, TargetType.APPLICATION));

  if (applicationTargets.length === 0) {
    throw new Error(`Could not find any application target in project.pbxproj`);
  }

  return applicationTargets[0];
}

function findNativeTargetByName(project, targetName) {
  const nativeTargets = getNativeTargets(project);
  const nativeTargetEntry = nativeTargets.find(([, i]) => i.name === targetName || i.name === `"${targetName}"`);

  if (!nativeTargetEntry) {
    throw new Error(`Could not find target '${targetName}' in project.pbxproj`);
  }

  return nativeTargetEntry;
}

function findNativeTargetById(project, targetId) {
  const nativeTargets = getNativeTargets(project);
  const nativeTargetEntry = nativeTargets.find(([key]) => key === targetId);

  if (!nativeTargetEntry) {
    throw new Error(`Could not find target with id '${targetId}' in project.pbxproj`);
  }

  return nativeTargetEntry;
}
//# sourceMappingURL=Target.js.map