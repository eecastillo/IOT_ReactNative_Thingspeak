"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getGoogleMapsApiKey = getGoogleMapsApiKey;
exports.setGoogleMapsApiKey = setGoogleMapsApiKey;
exports.addGoogleMapsAppDelegateImport = addGoogleMapsAppDelegateImport;
exports.removeGoogleMapsAppDelegateImport = removeGoogleMapsAppDelegateImport;
exports.addGoogleMapsAppDelegateInit = addGoogleMapsAppDelegateInit;
exports.removeGoogleMapsAppDelegateInit = removeGoogleMapsAppDelegateInit;
exports.addMapsCocoaPods = addMapsCocoaPods;
exports.removeMapsCocoaPods = removeMapsCocoaPods;
exports.withMaps = exports.MATCH_INIT = void 0;

function _fsExtra() {
  const data = _interopRequireDefault(require("fs-extra"));

  _fsExtra = function () {
    return data;
  };

  return data;
}

function _path() {
  const data = _interopRequireDefault(require("path"));

  _path = function () {
    return data;
  };

  return data;
}

function _iosPlugins() {
  const data = require("../plugins/ios-plugins");

  _iosPlugins = function () {
    return data;
  };

  return data;
}

function _withDangerousMod() {
  const data = require("../plugins/withDangerousMod");

  _withDangerousMod = function () {
    return data;
  };

  return data;
}

function _generateCode() {
  const data = require("../utils/generateCode");

  _generateCode = function () {
    return data;
  };

  return data;
}

function _resolvePackageRootFolder() {
  const data = require("../utils/resolvePackageRootFolder");

  _resolvePackageRootFolder = function () {
    return data;
  };

  return data;
}

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Match against `UMModuleRegistryAdapter` (unimodules), and React Native without unimodules (Expo Modules).
const MATCH_INIT = /(?:(self\.|_)(\w+)\s?=\s?\[\[UMModuleRegistryAdapter alloc\])|(?:RCTBridge\s?\*\s?(\w+)\s?=\s?\[\[RCTBridge alloc\])/g;
exports.MATCH_INIT = MATCH_INIT;
const withGoogleMapsKey = (0, _iosPlugins().createInfoPlistPlugin)(setGoogleMapsApiKey, 'withGoogleMapsKey');

const withMaps = config => {
  config = withGoogleMapsKey(config);
  const apiKey = getGoogleMapsApiKey(config); // Technically adds react-native-maps (Apple maps) and google maps.

  config = withMapsCocoaPods(config, {
    useGoogleMaps: !!apiKey
  }); // Adds/Removes AppDelegate setup for Google Maps API on iOS

  config = withGoogleMapsAppDelegate(config, {
    apiKey
  });
  return config;
};

exports.withMaps = withMaps;

function getGoogleMapsApiKey(config) {
  var _config$ios$config$go, _config$ios, _config$ios$config;

  return (_config$ios$config$go = (_config$ios = config.ios) === null || _config$ios === void 0 ? void 0 : (_config$ios$config = _config$ios.config) === null || _config$ios$config === void 0 ? void 0 : _config$ios$config.googleMapsApiKey) !== null && _config$ios$config$go !== void 0 ? _config$ios$config$go : null;
}

function setGoogleMapsApiKey(config, {
  GMSApiKey,
  ...infoPlist
}) {
  const apiKey = getGoogleMapsApiKey(config);

  if (apiKey === null) {
    return infoPlist;
  }

  return { ...infoPlist,
    GMSApiKey: apiKey
  };
}

function addGoogleMapsAppDelegateImport(src) {
  const newSrc = [];
  newSrc.push('#if __has_include(<GoogleMaps/GoogleMaps.h>)', '#import <GoogleMaps/GoogleMaps.h>', '#endif');
  return (0, _generateCode().mergeContents)({
    tag: 'react-native-maps-import',
    src,
    newSrc: newSrc.join('\n'),
    anchor: /#import "AppDelegate\.h"/,
    offset: 1,
    comment: '//'
  });
}

function removeGoogleMapsAppDelegateImport(src) {
  return (0, _generateCode().removeContents)({
    tag: 'react-native-maps-import',
    src
  });
}

function addGoogleMapsAppDelegateInit(src, apiKey) {
  const newSrc = [];
  newSrc.push('#if __has_include(<GoogleMaps/GoogleMaps.h>)', `  [GMSServices provideAPIKey:@"${apiKey}"];`, '#endif');
  return (0, _generateCode().mergeContents)({
    tag: 'react-native-maps-init',
    src,
    newSrc: newSrc.join('\n'),
    anchor: MATCH_INIT,
    offset: 0,
    comment: '//'
  });
}

function removeGoogleMapsAppDelegateInit(src) {
  return (0, _generateCode().removeContents)({
    tag: 'react-native-maps-init',
    src
  });
}
/**
 * @param src
 * @param useGoogleMaps
 * @param googleMapsPath '../node_modules/react-native-maps'
 * @returns
 */


function addMapsCocoaPods(src, googleMapsPath) {
  return (0, _generateCode().mergeContents)({
    tag: 'react-native-maps',
    src,
    newSrc: `  pod 'react-native-google-maps', path: '${googleMapsPath}'`,
    anchor: /use_native_modules/,
    offset: 0,
    comment: '#'
  });
}

function removeMapsCocoaPods(src) {
  return (0, _generateCode().removeContents)({
    tag: 'react-native-maps',
    src
  });
}

function isReactNativeMapsInstalled(projectRoot) {
  return (0, _resolvePackageRootFolder().resolvePackageRootFolder)(projectRoot, 'react-native-maps');
}

const withMapsCocoaPods = (config, {
  useGoogleMaps
}) => {
  return (0, _withDangerousMod().withDangerousMod)(config, ['ios', async config => {
    const filePath = _path().default.join(config.modRequest.platformProjectRoot, 'Podfile');

    const contents = await _fsExtra().default.readFile(filePath, 'utf-8');
    let results; // Only add the block if react-native-maps is installed in the project (best effort).
    // Generally prebuild runs after a yarn install so this should always work as expected.

    const googleMapsPath = isReactNativeMapsInstalled(config.modRequest.projectRoot);

    if (googleMapsPath && useGoogleMaps) {
      // Make the pod path relative to the ios folder.
      const googleMapsPodPath = _path().default.relative(config.modRequest.platformProjectRoot, googleMapsPath);

      try {
        results = addMapsCocoaPods(contents, googleMapsPodPath);
      } catch (error) {
        if (error.code === 'ERR_NO_MATCH') {
          throw new Error(`Cannot add react-native-maps to the project's ios/Podfile because it's malformed. Please report this with a copy of your project Podfile.`);
        }

        throw error;
      }
    } else {
      // If the package is no longer installed, then remove the block.
      results = removeMapsCocoaPods(contents);
    }

    if (results.didMerge || results.didClear) {
      await _fsExtra().default.writeFile(filePath, results.contents);
    }

    return config;
  }]);
};

const withGoogleMapsAppDelegate = (config, {
  apiKey
}) => {
  return (0, _iosPlugins().withAppDelegate)(config, config => {
    if (config.modResults.language === 'objc') {
      if (apiKey && isReactNativeMapsInstalled(config.modRequest.projectRoot)) {
        try {
          config.modResults.contents = addGoogleMapsAppDelegateImport(config.modResults.contents).contents;
          config.modResults.contents = addGoogleMapsAppDelegateInit(config.modResults.contents, apiKey).contents;
        } catch (error) {
          if (error.code === 'ERR_NO_MATCH') {
            throw new Error(`Cannot add Google Maps to the project's AppDelegate because it's malformed. Please report this with a copy of your project AppDelegate.`);
          }

          throw error;
        }
      } else {
        config.modResults.contents = removeGoogleMapsAppDelegateImport(config.modResults.contents).contents;
        config.modResults.contents = removeGoogleMapsAppDelegateInit(config.modResults.contents).contents;
      }
    } else {
      throw new Error('Cannot setup Google Maps because the AppDelegate is not Objective C');
    }

    return config;
  });
};
//# sourceMappingURL=Maps.js.map