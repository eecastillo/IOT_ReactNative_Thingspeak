import type { ExpoConfig } from '@expo/config-types';
import type { ConfigPlugin } from '../Plugin.types';
export declare const JS_ENGINE_PROP_KEY = "expo.jsEngine";
export declare const DEFAULT_JS_ENGINE = "jsc";
export declare const withJsEnginePodfileProps: ConfigPlugin;
export declare function getJsEngine(config: Pick<ExpoConfig, 'ios' | 'jsEngine'>): "hermes" | "jsc";
export declare function setJsEngine(config: Pick<ExpoConfig, 'ios' | 'jsEngine'>, podfileProperties: Record<string, string>): Record<string, string>;
