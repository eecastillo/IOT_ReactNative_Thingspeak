"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getGoogleSignInReservedClientId = getGoogleSignInReservedClientId;
exports.getGoogleServicesFile = getGoogleServicesFile;
exports.setGoogleSignInReservedClientId = setGoogleSignInReservedClientId;
exports.setGoogleConfig = setGoogleConfig;
exports.setGoogleServicesFile = setGoogleServicesFile;
exports.withGoogleServicesFile = exports.withGoogle = void 0;

function _fsExtra() {
  const data = _interopRequireDefault(require("fs-extra"));

  _fsExtra = function () {
    return data;
  };

  return data;
}

function _path() {
  const data = _interopRequireDefault(require("path"));

  _path = function () {
    return data;
  };

  return data;
}

function _iosPlugins() {
  const data = require("../plugins/ios-plugins");

  _iosPlugins = function () {
    return data;
  };

  return data;
}

function _Paths() {
  const data = require("./Paths");

  _Paths = function () {
    return data;
  };

  return data;
}

function _Scheme() {
  const data = require("./Scheme");

  _Scheme = function () {
    return data;
  };

  return data;
}

function _Xcodeproj() {
  const data = require("./utils/Xcodeproj");

  _Xcodeproj = function () {
    return data;
  };

  return data;
}

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const withGoogle = (0, _iosPlugins().createInfoPlistPlugin)(setGoogleConfig, 'withGoogle');
exports.withGoogle = withGoogle;

const withGoogleServicesFile = config => {
  return (0, _iosPlugins().withXcodeProject)(config, config => {
    config.modResults = setGoogleServicesFile(config, {
      projectRoot: config.modRequest.projectRoot,
      project: config.modResults
    });
    return config;
  });
};

exports.withGoogleServicesFile = withGoogleServicesFile;

function getGoogleSignInReservedClientId(config) {
  var _config$ios$config$go, _config$ios, _config$ios$config, _config$ios$config$go2;

  return (_config$ios$config$go = (_config$ios = config.ios) === null || _config$ios === void 0 ? void 0 : (_config$ios$config = _config$ios.config) === null || _config$ios$config === void 0 ? void 0 : (_config$ios$config$go2 = _config$ios$config.googleSignIn) === null || _config$ios$config$go2 === void 0 ? void 0 : _config$ios$config$go2.reservedClientId) !== null && _config$ios$config$go !== void 0 ? _config$ios$config$go : null;
}

function getGoogleServicesFile(config) {
  var _config$ios$googleSer, _config$ios2;

  return (_config$ios$googleSer = (_config$ios2 = config.ios) === null || _config$ios2 === void 0 ? void 0 : _config$ios2.googleServicesFile) !== null && _config$ios$googleSer !== void 0 ? _config$ios$googleSer : null;
}

function setGoogleSignInReservedClientId(config, infoPlist) {
  const reservedClientId = getGoogleSignInReservedClientId(config);

  if (reservedClientId === null) {
    return infoPlist;
  }

  return (0, _Scheme().appendScheme)(reservedClientId, infoPlist);
}

function setGoogleConfig(config, infoPlist) {
  infoPlist = setGoogleSignInReservedClientId(config, infoPlist);
  return infoPlist;
}

function setGoogleServicesFile(config, {
  projectRoot,
  project
}) {
  const googleServicesFileRelativePath = getGoogleServicesFile(config);

  if (googleServicesFileRelativePath === null) {
    return project;
  }

  const googleServiceFilePath = _path().default.resolve(projectRoot, googleServicesFileRelativePath);

  _fsExtra().default.copyFileSync(googleServiceFilePath, _path().default.join((0, _Paths().getSourceRoot)(projectRoot), 'GoogleService-Info.plist'));

  const projectName = (0, _Xcodeproj().getProjectName)(projectRoot);
  const plistFilePath = `${projectName}/GoogleService-Info.plist`;

  if (!project.hasFile(plistFilePath)) {
    project = (0, _Xcodeproj().addResourceFileToGroup)({
      filepath: plistFilePath,
      groupName: projectName,
      project,
      isBuildFile: true,
      verbose: true
    });
  }

  return project;
}
//# sourceMappingURL=Google.js.map