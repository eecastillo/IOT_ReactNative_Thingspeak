"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setProvisioningProfileForPbxproj = setProvisioningProfileForPbxproj;

function _fsExtra() {
  const data = _interopRequireDefault(require("fs-extra"));

  _fsExtra = function () {
    return data;
  };

  return data;
}

function _Target() {
  const data = require("./Target");

  _Target = function () {
    return data;
  };

  return data;
}

function _Xcodeproj() {
  const data = require("./utils/Xcodeproj");

  _Xcodeproj = function () {
    return data;
  };

  return data;
}

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function setProvisioningProfileForPbxproj(projectRoot, {
  targetName,
  profileName,
  appleTeamId,
  buildConfiguration = 'Release'
}) {
  const project = (0, _Xcodeproj().getPbxproj)(projectRoot);
  const nativeTargetEntry = targetName ? (0, _Target().findNativeTargetByName)(project, targetName) : (0, _Target().findFirstNativeTarget)(project);
  const [nativeTargetId, nativeTarget] = nativeTargetEntry;
  (0, _Xcodeproj().getBuildConfigurationsForListId)(project, nativeTarget.buildConfigurationList).filter(([, item]) => item.name === buildConfiguration).forEach(([, item]) => {
    item.buildSettings.PROVISIONING_PROFILE_SPECIFIER = `"${profileName}"`;
    item.buildSettings.DEVELOPMENT_TEAM = appleTeamId;
    item.buildSettings.CODE_SIGN_IDENTITY = '"iPhone Distribution"';
    item.buildSettings.CODE_SIGN_STYLE = 'Manual';
  });
  Object.entries((0, _Xcodeproj().getProjectSection)(project)).filter(_Xcodeproj().isNotComment).forEach(([, item]) => {
    item.attributes.TargetAttributes[nativeTargetId].DevelopmentTeam = appleTeamId;
    item.attributes.TargetAttributes[nativeTargetId].ProvisioningStyle = 'Manual';
  });

  _fsExtra().default.writeFileSync(project.filepath, project.writeSync());
}
//# sourceMappingURL=ProvisioningProfile.js.map