"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getName = getName;
exports.setDisplayName = setDisplayName;
exports.setName = setName;
exports.withName = exports.withDisplayName = void 0;

function _iosPlugins() {
  const data = require("../plugins/ios-plugins");

  _iosPlugins = function () {
    return data;
  };

  return data;
}

const withDisplayName = (0, _iosPlugins().createInfoPlistPlugin)(setDisplayName, 'withDisplayName');
exports.withDisplayName = withDisplayName;
const withName = (0, _iosPlugins().createInfoPlistPlugin)(setName, 'withName');
exports.withName = withName;

function getName(config) {
  return typeof config.name === 'string' ? config.name : null;
}
/**
 * CFBundleDisplayName is used for most things: the name on the home screen, in
 * notifications, and others.
 */


function setDisplayName(configOrName, {
  CFBundleDisplayName,
  ...infoPlist
}) {
  let name = null;

  if (typeof configOrName === 'string') {
    name = configOrName;
  } else {
    name = getName(configOrName);
  }

  if (!name) {
    return infoPlist;
  }

  return { ...infoPlist,
    CFBundleDisplayName: name
  };
}
/**
 * CFBundleName is recommended to be 16 chars or less and is used in lists, eg:
 * sometimes on the App Store
 */


function setName(config, {
  CFBundleName,
  ...infoPlist
}) {
  const name = getName(config);

  if (!name) {
    return infoPlist;
  }

  return { ...infoPlist,
    CFBundleName: name
  };
}
//# sourceMappingURL=Name.js.map