"use strict";
/* tslint:disable */
/**
 * The standard Expo config object defined in `app.config.js` files.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ExpoConfig.js.map