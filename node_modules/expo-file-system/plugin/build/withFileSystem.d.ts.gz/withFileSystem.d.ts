import { ConfigPlugin } from '@expo/config-plugins';
declare const _default: ConfigPlugin<void>;
export default _default;
