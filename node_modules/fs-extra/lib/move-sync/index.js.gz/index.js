'use strict'

module.exports = {
  moveSync: require('./move-sync')
}
