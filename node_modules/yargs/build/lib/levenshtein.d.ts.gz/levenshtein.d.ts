export declare function levenshtein(a: string, b: string): number;
