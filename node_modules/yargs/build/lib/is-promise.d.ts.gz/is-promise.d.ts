export declare function isPromise<T>(maybePromise: T | Promise<T>): maybePromise is Promise<T>;
