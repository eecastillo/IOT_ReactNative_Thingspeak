export declare function objFilter<T extends object>(original?: T, filter?: (k: keyof T, v: T[keyof T]) => boolean): T;
