export declare class YError extends Error {
    name: string;
    constructor(msg?: string | null);
}
