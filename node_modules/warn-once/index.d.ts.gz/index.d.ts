export default function warnOnce(condition: boolean, message?: any, ...optionalParams: any[]): void;
