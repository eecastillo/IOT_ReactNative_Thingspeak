'use strict';

module.exports = require('./async').unmemoize;
