import UnimplementedView from '../../modules/UnimplementedView';
export default UnimplementedView;