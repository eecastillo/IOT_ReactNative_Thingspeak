"use strict";

exports.__esModule = true;
exports.default = void 0;

var _RCTDeviceEventEmitter = _interopRequireDefault(require("../../vendor/react-native/NativeEventEmitter/RCTDeviceEventEmitter"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _RCTDeviceEventEmitter.default;
exports.default = _default;
module.exports = exports.default;