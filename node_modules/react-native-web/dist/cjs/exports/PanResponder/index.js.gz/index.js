"use strict";

exports.__esModule = true;
exports.default = void 0;

var _PanResponder = _interopRequireDefault(require("../../vendor/react-native/PanResponder"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _PanResponder.default;
exports.default = _default;
module.exports = exports.default;