// @flow strict

import PanResponder from '../../vendor/react-native/PanResponder';
export default PanResponder;
