declare const _default: import("expo-modules-core").ProxyNativeModule;
export default _default;
