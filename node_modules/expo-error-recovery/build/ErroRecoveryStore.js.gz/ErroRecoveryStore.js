let recoveredPropsToSave = null;
export function getRecoveryPropsToSave() {
    return recoveredPropsToSave;
}
export function setRecoveryPropsToSave(props) {
    recoveredPropsToSave = JSON.stringify(props);
}
//# sourceMappingURL=ErroRecoveryStore.js.map