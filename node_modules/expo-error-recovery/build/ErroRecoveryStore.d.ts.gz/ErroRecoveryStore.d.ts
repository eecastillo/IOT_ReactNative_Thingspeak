export declare function getRecoveryPropsToSave(): string | null;
export declare function setRecoveryPropsToSave(props: {
    [key: string]: any;
}): void;
