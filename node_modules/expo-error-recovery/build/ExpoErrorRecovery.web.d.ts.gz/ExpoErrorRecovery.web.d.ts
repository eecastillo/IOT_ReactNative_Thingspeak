declare const _default: {
    readonly name: string;
    saveRecoveryProps(props: string): void;
    recoveredProps: string | null;
};
export default _default;
