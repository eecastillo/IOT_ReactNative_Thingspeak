module.exports.browserVersions = require('../../data/browserVersions')
