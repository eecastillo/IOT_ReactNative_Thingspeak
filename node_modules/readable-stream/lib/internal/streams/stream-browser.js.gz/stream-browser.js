module.exports = require('events').EventEmitter;
