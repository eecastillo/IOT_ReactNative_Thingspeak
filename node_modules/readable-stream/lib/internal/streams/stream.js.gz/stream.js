module.exports = require('stream');
