"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.namedTypes = void 0;
var namedTypes;
(function (namedTypes) {
})(namedTypes = exports.namedTypes || (exports.namedTypes = {}));
