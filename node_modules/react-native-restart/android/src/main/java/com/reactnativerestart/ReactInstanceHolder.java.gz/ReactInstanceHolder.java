package com.reactnativerestart;

import com.facebook.react.ReactInstanceManager;

public interface ReactInstanceHolder {
    ReactInstanceManager getReactInstanceManager();
}