// __mocks__/react-native-restart.js

export default {
  Restart: jest.fn(),
};
