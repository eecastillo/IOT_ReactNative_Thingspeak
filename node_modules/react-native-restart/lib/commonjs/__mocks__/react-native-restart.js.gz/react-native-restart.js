"use strict";Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _default={Restart:jest.fn()};exports.default=_default;
//# sourceMappingURL=react-native-restart.js.map