/// <reference types="jest" />
declare const _default: {
    Restart: jest.Mock<any, any>;
};
export default _default;
