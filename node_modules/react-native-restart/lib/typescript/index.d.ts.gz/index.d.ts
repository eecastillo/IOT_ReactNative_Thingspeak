declare type RestartType = {
    Restart(): void;
};
declare const _default: RestartType;
export default _default;
