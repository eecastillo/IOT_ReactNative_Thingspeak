#import <React/RCTBridgeModule.h>
#import <React/RCTRootView.h>
#import <React/RCTReloadCommand.h>

@interface Restart : NSObject <RCTBridgeModule>

@end
