
module Expo
  module Constants
    GENERATED_GROUP_NAME = 'ExpoModulesProviders'
    MODULES_PROVIDER_FILE_NAME = 'ExpoModulesProvider.swift'
  end
end
